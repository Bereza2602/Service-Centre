const welcomeOverlay = document.getElementById('welcome-overlay')
const welcomeStart = document.getElementById('welcome-start')
const appMain = document.getElementById('app-main')
const parserListNode = document.getElementById('parser-list')
const parserInfoNode = document.getElementById('parser-info')
const formNode = document.getElementById('search-form')
const resultsNode = document.getElementById('results')
const messageNode = document.getElementById('message')
const statsNode = document.getElementById('result-stats')
const resultsTitleNode = document.getElementById('results-title')

const LANG = {
  ru: {
    welcomeTitle: 'Добро пожаловать!',
    welcomeDesc: 'Единый центр для поиска товаров, заведений и услуг. Выберите направление и начните поиск.',
    welcomeBtn: 'Начать работу',
    hdrSub: '/ центр парсеров',
    hdrBadge: 'все системы активны',
    panelTitle: 'Каталог услуг',
    resultsLabel: 'Результаты',
    resultsDefault: 'Выберите сервис и запустите поиск',
    messageWelcome: 'Добро пожаловать. Выберите нужный сервис слева, и форма поиска изменится под его задачу.',
    messageEmpty: 'Форма готова. Заполните параметры и нажмите запуск.',
    messageNoResults: 'По этим параметрам ничего не найдено. Попробуйте изменить запрос или лимит.',
    messageSearching: 'Парсер выполняет поиск. Для живых источников это может занять немного времени.',
    messageError: 'Не удалось выполнить поиск',
    messageInitError: 'Не удалось загрузить приложение',
    messageSuccess: (n) => `Готово. Парсер вернул ${n} карточек.`,
    submitBtn: 'Запустить поиск',
    resultsFound: 'Найдено',
    resultsShown: 'Показано',
    resultsCards: (n) => `Карточек: ${n}`,
    noName: 'Без названия',
    hasPhone: 'Есть телефон',
    hasSite: 'Есть сайт',
    searchOn: (s) => `Поиск на ${s}`,
  },
  en: {
    welcomeTitle: 'Welcome!',
    welcomeDesc: 'A single center for searching products, places, and services. Pick a category and start searching.',
    welcomeBtn: 'Get Started',
    hdrSub: '/ parser center',
    hdrBadge: 'all systems active',
    panelTitle: 'Services',
    resultsLabel: 'Results',
    resultsDefault: 'Select a service and run a search',
    messageWelcome: 'Welcome. Choose a service on the left to adjust the search form.',
    messageEmpty: 'The form is ready. Fill in the parameters and click search.',
    messageNoResults: 'Nothing found for these parameters. Try changing the query or limit.',
    messageSearching: 'The parser is searching. Live sources may take a moment.',
    messageError: 'Failed to run the search',
    messageInitError: 'Failed to load the application',
    messageSuccess: (n) => `Done. The parser returned ${n} cards.`,
    submitBtn: 'Run Search',
    resultsFound: 'Found',
    resultsShown: 'Shown',
    resultsCards: (n) => `Cards: ${n}`,
    noName: 'No name',
    hasPhone: 'Has phone',
    hasSite: 'Has site',
    searchOn: (s) => `Search on ${s}`,
  },
}

function t(key, ...args) {
  const val = LANG[lang][key]
  return typeof val === 'function' ? val(...args) : val
}

const SERVICE_ICONS = {
  electronics: '<img src="/electronics-icon.png" alt="Электроника" class="parser-svg-icon">',
  restaurants: '<img src="/restaurants-icon.png" alt="Рестораны" class="parser-svg-icon">',
  entertainment: '<img src="/entertainment-icon.png" alt="Досуг" class="parser-svg-icon">',
  pharmacy: '<img src="/pharmacy-icon.png" alt="Аптеки" class="parser-svg-icon">',
}

const PARSER_BADGES = {
  electronics: '01',
  pharmacy: '04',
  entertainment: '03',
  restaurants: '02',
}

const ELECTRONICS_SOURCES = [
  ['catalog', 'Локальная база'],
  ['yandex-market', 'Яндекс Маркет'],
  ['regard', '\u0420\u0435\u0433\u0430\u0440\u0434'],
  ['chipdip', 'ChipDip'],
]

const PHARMACY_SOURCES = [
  ['eapteka', '\u0415\u0410\u041F\u0422\u0415\u041A\u0410'],
  ['uteka', '\u042E\u0442\u0435\u043A\u0430'],
  ['apteka-ru', 'Apteka.ru'],
  ['zdravcity', '\u0417\u0434\u0440\u0430\u0432\u0441\u0438\u0442\u0438'],
]

const ENTERTAINMENT_CATEGORIES = [
  ['all', '\u0412\u0441\u0435'],
  ['bowling', '\u0411\u043E\u0443\u043B\u0438\u043D\u0433'],
  ['computer_club', '\u041F\u041A-\u043A\u043B\u0443\u0431\u044B'],
  ['cinema', '\u041A\u0438\u043D\u043E'],
  ['quest', '\u041A\u0432\u0435\u0441\u0442\u044B'],
  ['nightclub', '\u041A\u043B\u0443\u0431\u044B'],
  ['bar', '\u0411\u0430\u0440\u044B'],
  ['waterpark', '\u0410\u043A\u0432\u0430\u043F\u0430\u0440\u043A\u0438'],
]

const PARSER_FORMS = {
  electronics: {
    defaults: { query: '', brand: '', category: '', priceMin: '', priceMax: '', sortBy: 'price-asc', sources: [] },
    fields: [
      { type: 'text', name: 'query', label: '\u0427\u0442\u043E \u0438\u0449\u0435\u043C', placeholder: 'iPhone, \u0441\u043C\u0430\u0440\u0442\u0444\u043E\u043D, \u043C\u043E\u043D\u0438\u0442\u043E\u0440, \u043D\u043E\u0443\u0442\u0431\u0443\u043A' },
      { type: 'select', name: 'brand', label: '\u0411\u0440\u0435\u043D\u0434', options: [['', '\u0412\u0441\u0435 \u0431\u0440\u0435\u043D\u0434\u044B'],['Apple','Apple'],['Samsung','Samsung'],['Xiaomi','Xiaomi'],['Sony','Sony'],['LG','LG'],['Huawei','Huawei'],['Lenovo','Lenovo'],['ASUS','ASUS']] },
      { type: 'select', name: 'category', label: '\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F', options: [['','\u0412\u0441\u0435 \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0438'],['smartphone','\u0421\u043C\u0430\u0440\u0442\u0444\u043E\u043D\u044B'],['headphones','\u041D\u0430\u0443\u0448\u043D\u0438\u043A\u0438'],['laptop','\u041D\u043E\u0443\u0442\u0431\u0443\u043A\u0438'],['monitor','\u041C\u043E\u043D\u0438\u0442\u043E\u0440\u044B'],['smartwatch','\u0423\u043C\u043D\u044B\u0435 \u0447\u0430\u0441\u044B'],['tablet','\u041F\u043B\u0430\u043D\u0448\u0435\u0442\u044B'],['console','\u0418\u0433\u0440\u043E\u0432\u044B\u0435 \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0430']] },
      { type: 'number', name: 'priceMin', label: '\u0426\u0435\u043D\u0430 \u043E\u0442', placeholder: '10000' },
      { type: 'number', name: 'priceMax', label: '\u0426\u0435\u043D\u0430 \u0434\u043E', placeholder: '80000' },
      { type: 'select', name: 'sortBy', label: '\u0421\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u043A\u0430', options: [['price-asc','\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0434\u0435\u0448\u0435\u0432\u043B\u0435'],['price-desc','\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0434\u043E\u0440\u043E\u0436\u0435'],['title-asc','\u041F\u043E \u043D\u0430\u0437\u0432\u0430\u043D\u0438\u044E']] },
      { type: 'chips', name: 'sources', label: '\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u0438', options: ELECTRONICS_SOURCES, defaultValues: ELECTRONICS_SOURCES },
    ],
  },
  pharmacy: {
    defaults: { city: 'ekaterinburg', query: '\u043D\u0443\u0440\u043E\u0444\u0435\u043D', maxPrice: '700', sortBy: 'price-asc', onlyInStock: true, limit: '50', sources: PHARMACY_SOURCES.map(([v]) => v) },
    fields: [
      { type: 'text', name: 'query', label: '\u041B\u0435\u043A\u0430\u0440\u0441\u0442\u0432\u043E \u0438\u043B\u0438 \u0442\u043E\u0432\u0430\u0440', placeholder: '\u041D\u0443\u0440\u043E\u0444\u0435\u043D, \u041E\u043C\u0435\u0433\u0430-3, \u0410\u043A\u0432\u0430\u0434\u0435\u0442\u0440\u0438\u043C' },
      { type: 'select', name: 'city', label: '\u0413\u043E\u0440\u043E\u0434', options: [['ekaterinburg','\u0415\u043A\u0430\u0442\u0435\u0440\u0438\u043D\u0431\u0443\u0440\u0433'],['moskva','\u041C\u043E\u0441\u043A\u0432\u0430'],['sankt-peterburg','\u0421\u0430\u043D\u043A\u0442-\u041F\u0435\u0442\u0435\u0440\u0431\u0443\u0440\u0433'],['kazan','\u041A\u0430\u0437\u0430\u043D\u044C'],['novosibirsk','\u041D\u043E\u0432\u043E\u0441\u0438\u0431\u0438\u0440\u0441\u043A'],['orenburg','\u041E\u0440\u0435\u043D\u0431\u0443\u0440\u0433'],['samara','\u0421\u0430\u043C\u0430\u0440\u0430'],['ufa','\u0423\u0444\u0430'],['chelyabinsk','\u0427\u0435\u043B\u044F\u0431\u0438\u043D\u0441\u043A'],['rostov','\u0420\u043E\u0441\u0442\u043E\u0432-\u043D\u0430-\u0414\u043E\u043D\u0443']] },
      { type: 'number', name: 'maxPrice', label: '\u0426\u0435\u043D\u0430 \u0434\u043E', placeholder: '700' },
      { type: 'number', name: 'limit', label: '\u041B\u0438\u043C\u0438\u0442', placeholder: '50' },
      { type: 'select', name: 'sortBy', label: '\u0421\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u043A\u0430', options: [['price-asc','\u0421\u043D\u0430\u0447\u0430\u043B\u0430 \u0434\u0435\u0448\u0435\u0432\u043B\u0435'],['distance-asc','\u0411\u043B\u0438\u0436\u0435 \u043A \u0446\u0435\u043D\u0442\u0440\u0443'],['stock-desc','\u0411\u043E\u043B\u044C\u0448\u0435 \u0432 \u043D\u0430\u043B\u0438\u0447\u0438\u0438']] },
      { type: 'checkbox', name: 'onlyInStock', label: '\u0422\u043E\u043B\u044C\u043A\u043E \u0432 \u043D\u0430\u043B\u0438\u0447\u0438\u0438' },
      { type: 'chips', name: 'sources', label: '\u0418\u0441\u0442\u043E\u0447\u043D\u0438\u043A\u0438', options: PHARMACY_SOURCES },
    ],
  },
  entertainment: {
    defaults: { city: '\u0415\u043A\u0430\u0442\u0435\u0440\u0438\u043D\u0431\u0443\u0440\u0433', searchText: '', categories: ['all'], limit: '30' },
    fields: [
      { type: 'text', name: 'city', label: '\u0413\u043E\u0440\u043E\u0434', placeholder: '\u0415\u043A\u0430\u0442\u0435\u0440\u0438\u043D\u0431\u0443\u0440\u0433' },
      { type: 'text', name: 'searchText', label: '\u0422\u0435\u043A\u0441\u0442\u043E\u0432\u044B\u0439 \u043F\u043E\u0438\u0441\u043A', placeholder: '\u0431\u043E\u0443\u043B\u0438\u043D\u0433, \u043A\u0438\u043D\u043E, cyber, hookah' },
      { type: 'chips', name: 'categories', label: '\u0427\u0442\u043E \u0438\u0441\u043A\u0430\u0442\u044C', options: ENTERTAINMENT_CATEGORIES, singleAll: true },
      { type: 'number', name: 'limit', label: '\u0421\u043A\u043E\u043B\u044C\u043A\u043E \u043C\u0435\u0441\u0442 \u0432\u0435\u0440\u043D\u0443\u0442\u044C', placeholder: '30' },
    ],
  },
  restaurants: {
    defaults: { city: 'ekaterinburg', query: '\u0440\u0435\u0441\u0442\u043E\u0440\u0430\u043D\u044B \u0438 \u043A\u0430\u0444\u0435', profile: 'restaurants', limit: '8', withWebsitePhones: true, services: [] },
    fields: [
      { type: 'text', name: 'city', label: '\u0413\u043E\u0440\u043E\u0434', placeholder: 'ekaterinburg, moscow, kazan' },
      { type: 'text', name: 'query', label: '\u0417\u0430\u043F\u0440\u043E\u0441', placeholder: '\u0440\u0435\u0441\u0442\u043E\u0440\u0430\u043D\u044B, \u043A\u0430\u0444\u0435, \u043F\u0438\u0446\u0446\u0430, \u0431\u0430\u0440, \u043C\u043E\u0440\u0441\u043A\u0430\u044F \u043A\u0443\u0445\u043D\u044F' },
      { type: 'select', name: 'profile', label: '\u041F\u0440\u043E\u0444\u0438\u043B\u044C', options: [['restaurants','\u0420\u0435\u0441\u0442\u043E\u0440\u0430\u043D\u044B \u0438 \u043A\u0430\u0444\u0435'],['universal','\u041B\u044E\u0431\u044B\u0435 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0438']] },
      { type: 'chips', name: 'services', label: '\u0423\u0441\u043B\u0443\u0433\u0438', options: [['\u043D\u0430\u0432\u044B\u043D\u043E\u0441','\u041D\u0430 \u0432\u044B\u043D\u043E\u0441'],['\u0434\u043E\u0441\u0442\u0430\u0432\u043A\u0430','\u0414\u043E\u0441\u0442\u0430\u0432\u043A\u0430']] },
      { type: 'number', name: 'limit', label: '\u041B\u0438\u043C\u0438\u0442', placeholder: '8' },
      { type: 'checkbox', name: 'withWebsitePhones', label: '\u0418\u0441\u043A\u0430\u0442\u044C \u0442\u0435\u043B\u0435\u0444\u043E\u043D\u044B \u043D\u0430 \u0441\u0430\u0439\u0442\u0430\u0445' },
    ],
  },
}

let parsers = []
let activeParserId = 'electronics'
let formState = structuredClone(PARSER_FORMS.electronics.defaults)

const savedTheme = localStorage.getItem('theme')
const prefersLight = window.matchMedia('(prefers-color-scheme: light)').matches
let theme = savedTheme || (prefersLight ? 'light' : 'dark')
let lang = localStorage.getItem('lang') || 'ru'

function applyTheme() {
  document.documentElement.setAttribute('data-theme', theme === 'light' ? 'light' : 'dark')
  const btn = document.getElementById('toggle-theme')
  if (btn) btn.textContent = theme === 'light' ? '\u{1F319}' : '\u2600\uFE0F'
  localStorage.setItem('theme', theme)
}

function toggleTheme() {
  theme = theme === 'light' ? 'dark' : 'light'
  applyTheme()
}

function applyLang() {
  const btn = document.getElementById('toggle-lang')
  if (btn) btn.textContent = lang === 'ru' ? 'EN' : 'RU'
  document.documentElement.lang = lang
  localStorage.setItem('lang', lang)

  const hdrSub = document.querySelector('.hdr-sub')
  if (hdrSub) hdrSub.textContent = t('hdrSub')
  const hdrBadge = document.querySelector('.header-badge')
  if (hdrBadge) hdrBadge.textContent = t('hdrBadge')

  const wsTitle = document.querySelector('.welcome-card h1')
  if (wsTitle) wsTitle.textContent = t('welcomeTitle')
  const wsDesc = document.querySelector('.welcome-desc')
  if (wsDesc) wsDesc.textContent = t('welcomeDesc')
  const wsBtn = document.getElementById('welcome-start')
  if (wsBtn) wsBtn.textContent = t('welcomeBtn')

  const panelTitle = document.querySelector('.panel-title span')
  if (panelTitle) panelTitle.textContent = t('panelTitle')

  const resLabel = document.querySelector('.eyebrow')
  if (resLabel) resLabel.textContent = t('resultsLabel')

  if (!resultsNode.children.length) {
    resultsTitleNode.textContent = t('resultsDefault')
    setMessage(t('messageWelcome'), 'empty')
  }
}

function toggleLang() {
  lang = lang === 'ru' ? 'en' : 'ru'
  applyLang()
}

function escapeHtml(v) {
  return String(v).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;')
}

function setMessage(text, type = 'empty') {
  messageNode.className = `message ${type}`.trim()
  messageNode.textContent = text
}

function buildSearchParams() {
  const params = new URLSearchParams()
  Object.entries(formState).forEach(([key, value]) => {
    if (Array.isArray(value)) { if (value.length) params.set(key, value.join(',')); return }
    if (typeof value === 'boolean') { if (value) params.set(key, 'true'); else if (key === 'withWebsitePhones') params.set(key, '0'); return }
    if (String(value).trim()) params.set(key, String(value).trim())
  })
  return params
}

function updateQueryPreview() {
  const el = formNode.querySelector('.query-preview')
  if (el) el.textContent = `/api/search/${activeParserId}?${buildSearchParams().toString()}`
}

function renderParserList() {
  parserListNode.innerHTML = parsers.map(p => `
    <button class="parser-card ${p.id === activeParserId ? 'active' : ''}" data-parser="${p.id}" type="button">
      <span class="parser-mark">${SERVICE_ICONS[p.id] || ''}</span>
      <strong>${escapeHtml(p.title)}</strong>
      <small>${escapeHtml(p.description)}</small>
    </button>
  `).join('')
  parserListNode.querySelectorAll('button').forEach(b => {
    b.addEventListener('click', () => selectParser(b.dataset.parser))
  })
}

function renderParserInfo() {
  const parser = parsers.find(p => p.id === activeParserId)
  parserInfoNode.innerHTML = `
    <div class="parser-info-left">
      <div class="parser-info-icon">${SERVICE_ICONS[parser.id] || ''}</div>
      <div class="parser-info-text">
        <h2>${escapeHtml(parser.title)}</h2>
        <p>${escapeHtml(parser.description)}</p>
      </div>
    </div>
    <div class="parser-info-tag">${escapeHtml(parser.source)}</div>
  `
  parserInfoNode.parentElement.setAttribute('data-service', parser.id)
}

function createField(field) {
  const value = formState[field.name]
  if (field.type === 'select') {
    return `<label class="field"><span>${escapeHtml(field.label)}</span><select name="${escapeHtml(field.name)}">${
      field.options.map(([ov, l]) => `<option value="${escapeHtml(ov)}" ${value === ov ? 'selected' : ''}>${escapeHtml(l)}</option>`).join('')
    }</select></label>`
  }
  if (field.type === 'checkbox') {
    return `<label class="check-field"><input name="${escapeHtml(field.name)}" type="checkbox" ${value ? 'checked' : ''} /><span>${escapeHtml(field.label)}</span></label>`
  }
  if (field.type === 'chips') {
    const selected = Array.isArray(value) ? value : []
    const defaults = field.defaultValues ? field.defaultValues.map(([v]) => v) : null
    return `<div class="field wide"><span>${escapeHtml(field.label)}</span><div class="chip-grid" data-chip-group="${escapeHtml(field.name)}" data-single-all="${field.singleAll ? '1' : '0'}">${
      field.options.map(([ov, l]) => `<button class="chip ${selected.includes(ov) ? 'active' : ''}" type="button" data-value="${escapeHtml(ov)}">${escapeHtml(l)}</button>`).join('')
    }${defaults ? `<button class="chip btn-auto ${selected.join(',') === defaults.join(',') ? 'auto-active' : ''}" type="button" data-auto="${escapeHtml(field.name)}">\u0410\u0432\u0442\u043E</button>` : ''}</div></div>`
  }
  return `<label class="field"><span>${escapeHtml(field.label)}</span><input name="${escapeHtml(field.name)}" type="text" inputmode="${field.type === 'number' ? 'numeric' : 'text'}" value="${escapeHtml(value)}" placeholder="${escapeHtml(field.placeholder || '')}" /></label>`
}

function renderForm() {
  const config = PARSER_FORMS[activeParserId]
  const params = buildSearchParams()
  formNode.innerHTML = `<div class="form-grid">${config.fields.map(createField).join('')}</div><div class="form-footer"><button class="submit-button" type="submit"><span class="spinner" style="display:none"></span> ${escapeHtml(t('submitBtn'))}</button><code class="query-preview">/api/search/${activeParserId}?${escapeHtml(params.toString())}</code></div>`
  formNode.querySelectorAll('input, select').forEach(f => { f.addEventListener('input', handleFieldChange); f.addEventListener('change', handleFieldChange) })
  formNode.querySelectorAll('.chip-grid').forEach(g => {
    g.querySelectorAll('button:not(.btn-auto)').forEach(b => { b.addEventListener('click', () => toggleChip(g.dataset.chipGroup, b.dataset.value, g.dataset.singleAll === '1')) })
    const autoBtn = g.querySelector('.btn-auto')
    if (autoBtn) autoBtn.addEventListener('click', () => resetChips(g.dataset.chipGroup))
  })
}

function handleFieldChange(e) {
  const f = e.target
  if (f.type === 'checkbox') formState[f.name] = f.checked
  else if (f.inputMode === 'numeric') formState[f.name] = f.value.replace(/[^\d]/g, '')
  else formState[f.name] = f.value
  updateQueryPreview()
}

function toggleChip(name, value, singleAll) {
  const current = Array.isArray(formState[name]) ? formState[name] : []
  let next
  if (singleAll && value === 'all') { next = ['all'] }
  else { next = current.includes(value) ? current.filter(i => i !== value && i !== 'all') : [...current.filter(i => i !== 'all'), value] }
  formState[name] = next.length ? next : singleAll ? ['all'] : []
  renderForm()
}

function resetChips(name) {
  const config = PARSER_FORMS[activeParserId]
  const field = config.fields.find(f => f.name === name)
  if (field && field.defaultValues) {
    formState[name] = field.defaultValues.map(([v]) => v)
  }
  renderForm()
}

function selectParser(parserId) {
  activeParserId = parserId
  formState = structuredClone(PARSER_FORMS[parserId].defaults)
  resultsNode.innerHTML = ''
  statsNode.innerHTML = ''
  resultsTitleNode.textContent = t('resultsDefault')
  setMessage(t('messageEmpty'), 'empty')
  renderParserList()
  renderParserInfo()
  renderForm()
}

function getItems(payload) {
  if (Array.isArray(payload.offers)) return payload.offers
  if (Array.isArray(payload.venues)) return payload.venues
  if (Array.isArray(payload.items)) return payload.items
  return []
}

function itemTitle(item) {
  return item.title || item.productName || item.pharmacyName || item.name || t('noName')
}

function itemPrice(item) {
  if (item.priceText) {
    if (item.oldPriceText) {
      return `${item.priceText} <s style="opacity:0.5;font-weight:400;font-size:14px">${item.oldPriceText}</s>`
    }
    return item.priceText
  }
  if (item.pricePerUnit) return item.pricePerUnit
  if (item.averagePrice) return `\u0427\u0435\u043A ${item.averagePrice.toLocaleString('ru-RU')} \u20BD`
  if (item.rating) return `\u0420\u0435\u0439\u0442\u0438\u043D\u0433 ${item.rating}`
  return ''
}

function itemAddress(item) {
  const addr = item.address || item.subtitle || item.categoryLabel || item.sourceLabel || ''
  const phone = item.websitePhone || item.phone
  if (phone) return `${addr} \u2022 ${phone}`
  return addr
}

function itemDescription(item) {
  return item.description || item.schedule || item.openingHours || item.network || ''
}

function itemTags(item) {
  const tags = []
  if (item.brand) tags.push({ text: item.brand })
  if (item.store) tags.push({ text: item.store })
  if (item.categoryLabel) tags.push({ text: item.categoryLabel })
  if (item.distanceText) tags.push({ text: item.distanceText })
  if (item.sourceLabel) tags.push({ text: item.sourceLabel })
  if (item.prescriptionText) tags.push({ text: item.prescriptionText, cls: 'tag-rx' })
  if (item.stockLabel) {
    const cls = item.stockLabel === '\u041D\u0435\u0442 \u0432 \u043D\u0430\u043B\u0438\u0447\u0438\u0438' ? 'tag-out' : item.stockLabel === '\u0417\u0430\u043A\u0430\u043D\u0447\u0438\u0432\u0430\u0435\u0442\u0441\u044F' ? 'tag-low' : item.stockLabel === '\u0412\u044B\u0441\u0442\u0430\u0432\u043E\u0447\u043D\u044B\u0439 \u044D\u043A\u0437\u0435\u043C\u043F\u043B\u044F\u0440' ? 'tag-exhibit' : ''
    tags.push({ text: item.stockLabel, cls })
  }
  if (item.cuisine) tags.push({ text: '\u{1F373} ' + item.cuisine })
  if (Array.isArray(item.services) && item.services.length) tags.push(...item.services.map(s => ({ text: '\u2714' + s })))
  if (item.reviewCount) tags.push({ text: '\u{1F4AC} ' + item.reviewCount.toLocaleString('ru-RU') })
  return tags
}

function itemLinks(item) {
  const primaryUrl = item.reserveUrl || item.website || item.url || item.detailUrl || item.sourcePage
  const hasPrice = Number.isFinite(item.price)
  const source = item.store || item.sourceLabel || ''
  const openLabel = hasPrice || !primaryUrl ? '\u041E\u0442\u043A\u0440\u044B\u0442\u044C' : t('searchOn', source)
  const links = [
    [openLabel, primaryUrl],
  ]
  const siteUrl = item.website && item.website !== primaryUrl ? item.website : null
  const pageUrl = item.sourcePage && item.sourcePage !== primaryUrl && item.sourcePage !== item.website ? item.sourcePage : null
  if (siteUrl) links.push(['\u0421\u0430\u0439\u0442', siteUrl])
  if (pageUrl) links.push(['OSM', pageUrl])
  links.push(
    ['\u041A\u0430\u0440\u0442\u0430', item.mapUrl || item.yandexMapUrl || item.mapLinks?.yandex],
    ['Google', item.googleMapsUrl || item.mapLinks?.google],
  )
  return links.filter(([, h]) => h)
}

function renderStats(payload, items) {
  const textParts = []
  if (payload.filtered !== undefined) textParts.push(`${t('resultsFound')}: ${payload.filtered}`)
  if (payload.meta?.totalOffers !== undefined) textParts.push(`${t('resultsFound')}: ${payload.meta.totalOffers}`)
  if (payload.returned !== undefined) textParts.push(`${t('resultsShown')}: ${payload.returned}`)
  if (payload.count !== undefined) textParts.push(`${t('resultsFound')}: ${payload.count}`)
  if (!textParts.length) textParts.push(t('resultsCards', items.length))
  const htmlParts = textParts.map(p => `<span>${escapeHtml(p)}</span>`)
  const statuses = payload.meta?.sourceStatuses
  if (statuses && statuses.length) {
    statuses.forEach(s => {
      const icon = s.ok ? '\u2705' : s.skipped ? '\u26AA' : '\u26D4'
      const cls = s.ok ? 'status-ok' : s.skipped ? 'status-skip' : 'status-fail'
      htmlParts.push(`<span class="source-status ${cls}" title="${escapeHtml(s.reason || '')}">${icon} ${escapeHtml(s.sourceLabel)} (${s.count})</span>`)
    })
  }
  statsNode.innerHTML = htmlParts.join('')
}

function renderResults(payload) {
  const items = getItems(payload)
  renderStats(payload, items)
  resultsTitleNode.textContent = parsers.find(p => p.id === activeParserId).title
  if (!items.length) {
    resultsNode.innerHTML = ''
    setMessage(t('messageNoResults'), 'empty')
    return
  }
  setMessage(t('messageSuccess', items.length), 'success')
  resultsNode.innerHTML = items.map(item => {
    const ratingStars = item.rating ? '\u2B50'.repeat(Math.round(item.rating / 2)) : ''
    const sourceLabel = item.website ? new URL(item.website).hostname.replace('www.', '') : activeParserId
    return `
    <article class="result-card">
      <div class="result-media">
        <span>${escapeHtml(sourceLabel)}</span>
        ${itemPrice(item) ? `<strong>${itemPrice(item)}</strong>` : ''}
        ${ratingStars ? `<span style="font-size:1.2em">${ratingStars}</span>` : ''}
      </div>
      <div class="result-body">
        <h3>${escapeHtml(itemTitle(item))}</h3>
        ${itemAddress(item) ? `<p class="address">${escapeHtml(itemAddress(item))}</p>` : ''}
        ${itemDescription(item) ? `<p>${escapeHtml(itemDescription(item))}</p>` : ''}
        <div class="tag-row">${itemTags(item).map(t => `<span${t.cls ? ` class="${t.cls}"` : ''}>${escapeHtml(t.text)}</span>`).join('')}</div>
        <div class="actions">${itemLinks(item).map(([l, h]) => `<a href="${escapeHtml(h)}" target="_blank" rel="noreferrer">${escapeHtml(l)}</a>`).join('')}</div>
      </div>
    </article>
  `}).join('')
}

async function handleSubmit(e) {
  e.preventDefault()
  const button = formNode.querySelector('.submit-button')
  const spinner = button.querySelector('.spinner')
  const params = buildSearchParams()
  button.disabled = true
  if (spinner) spinner.style.display = 'inline-block'
  resultsNode.innerHTML = ''
  statsNode.innerHTML = ''
  setMessage(t('messageSearching'), 'empty')
  try {
    const response = await fetch(`/api/search/${activeParserId}?${params.toString()}`)
    const result = await response.json()
    if (!response.ok) throw new Error(result.details || result.error || t('messageError'))
    renderResults(result.payload)
  } catch (error) {
    setMessage(error instanceof Error ? error.message : t('messageError'), 'error')
  } finally {
    button.disabled = false
    if (spinner) spinner.style.display = 'none'
    renderForm()
  }
}

document.getElementById('toggle-theme')?.addEventListener('click', toggleTheme)
document.getElementById('toggle-lang')?.addEventListener('click', toggleLang)

let welcomeSelectedParser = null

document.querySelectorAll('.ws-item').forEach(el => {
  el.addEventListener('click', () => {
    document.querySelectorAll('.ws-item').forEach(i => i.classList.remove('selected'))
    el.classList.add('selected')
    welcomeSelectedParser = el.dataset.parser
    welcomeStart.disabled = false
  })
})

welcomeStart.addEventListener('click', () => {
  if (!welcomeSelectedParser) return
  welcomeStart.classList.add('clicked')
  welcomeOverlay.style.opacity = '0'
  welcomeOverlay.style.transition = 'opacity 0.5s ease'
  setTimeout(() => {
    welcomeOverlay.classList.add('hidden')
    appMain.classList.remove('hidden')
    appMain.style.animation = 'fadeUp 0.5s ease-out'
    selectParser(welcomeSelectedParser)
  }, 500)
})

async function init() {
  const response = await fetch('/api/parsers')
  const payload = await response.json()
  parsers = payload.parsers
  formNode.addEventListener('submit', handleSubmit)
  applyTheme()
  applyLang()
  selectParser(activeParserId)
}

init().catch(error => {
  setMessage(error instanceof Error ? error.message : t('messageInitError'), 'error')
})
