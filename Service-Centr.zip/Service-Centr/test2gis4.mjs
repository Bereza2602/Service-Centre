﻿import https from 'https';

function fetchUrl(url, headers, redirectCount = 0) {
  return new Promise((resolve, reject) => {
    if (redirectCount > 5) return reject(new Error('Too many redirects'));
    const u = new URL(url);
    https.get(url, { headers }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400) {
        console.log('Redirect', res.statusCode, 'to:', res.headers.location);
        fetchUrl(new URL(res.headers.location, url).href, headers, redirectCount + 1).then(resolve);
        return;
      }
      let data = Buffer.alloc(0);
      res.on('data', (chunk) => data = Buffer.concat([data, chunk]));
      res.on('end', () => {
        console.log('Final URL:', url);
        console.log('Status:', res.statusCode);
        console.log('Length:', data.length);
        const text = data.toString('utf8');
        console.log('Has firm data (_1rehek):', text.includes('_1rehek'));
        console.log('Has root div:', text.includes('<div id="root">'));
        if (text.length > 100) console.log('First 200:', text.substring(0, 200));
        resolve();
      });
    }).on('error', reject);
  });
}

const headers = {
  'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
  'accept-language': 'ru-RU,ru;q=0.9,en;q=0.8',
  'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
};
await fetchUrl('https://2gis.ru/ekaterinburg/search/%D1%80%D0%B5%D1%81%D1%82%D0%BE%D1%80%D0%B0%D0%BD', headers);
