// @ts-check
/** @type {import("lage").ConfigFileOptions} */
const config = {
  // Define your tasks and their dependencies here
  pipeline: {
    build: ["^build"],
    test: ["build"],
    lint: [],
  },
  npmClient: "npm",
  // Update these according to your repo's build setup
  cacheOptions: {
    // Generated files in each package that will be saved into the cache
    // (relative to package root; folders must end with **/*)
    outputGlob: ["lib/**/*"],
    // Changes to any of these files/globs will invalidate the cache (relative to repo root;
    // folders must end with **/*). This should include any repo-wide configs or scripts that
    // are outside a package but could invalidate previous output. Including the lock file is
    // optional--lage attempts to more granularly check resolved dependency changes, but this
    // isn't entirely reliable, especially for peerDependencies.
    environmentGlob: ["package.json","package-lock.json","lage.config.js"],
  },
};
module.exports = config;
