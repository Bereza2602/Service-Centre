import http from 'node:http'
import { URL } from 'node:url'
import { searchElectronics } from './search-service.js'

const PORT = Number(process.env.PORT || 3011)

function sendJson(response, statusCode, payload) {
  response.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  })

  response.end(JSON.stringify(payload))
}

const server = http.createServer(async (request, response) => {
  if (!request.url) {
    sendJson(response, 400, { error: 'Empty request URL' })
    return
  }

  if (request.method === 'OPTIONS') {
    response.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    })
    response.end()
    return
  }

  const url = new URL(request.url, `http://${request.headers.host}`)

  if (request.method === 'GET' && url.pathname === '/api/health') {
    sendJson(response, 200, { ok: true })
    return
  }

  if (request.method === 'GET' && url.pathname === '/api/search') {
    try {
      const query = url.searchParams.get('query') || ''
      const brand = url.searchParams.get('brand') || ''
      const category = url.searchParams.get('category') || ''
      const priceMinRaw = url.searchParams.get('priceMin')
      const priceMaxRaw = url.searchParams.get('priceMax')
      const sortBy = url.searchParams.get('sortBy') || 'price-asc'
      const sources = url.searchParams.get('sources') || ''

      const result = await searchElectronics({
        query,
        brand,
        category,
        priceMin: priceMinRaw ? Number(priceMinRaw) : null,
        priceMax: priceMaxRaw ? Number(priceMaxRaw) : null,
        sortBy,
        sources,
      })

      sendJson(response, 200, result)
      return
    } catch (error) {
      sendJson(response, 500, {
        error: 'Failed to fetch electronics catalog',
        details: error instanceof Error ? error.message : 'Unknown error',
      })
      return
    }
  }

  sendJson(response, 404, { error: 'Not found' })
})

server.listen(PORT, () => {
  console.log(`Electronics parser API is running on http://localhost:${PORT}`)
})
