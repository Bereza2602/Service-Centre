import {
  createFallbackSearchOffer,
  createSourceError,
  createSourceResult,
  dedupeOffers,
  fetchText,
  getSearchText,
  matchFilters,
  parseJsonLdProducts,
} from './shared.js'

export function buildSearchUrl(baseUrl, path, queryParam, filters) {
  const searchText = getSearchText(filters)
  const url = new URL(path, baseUrl)

  if (searchText) {
    url.searchParams.set(queryParam, searchText)
  }

  return url.toString()
}

async function parseFromHtml(source, html) {
  const parsed = parseJsonLdProducts(
    html,
    source.id,
    source.label,
    source.baseUrl,
  )

  if (parsed.length) {
    return parsed
  }

  if (typeof source.parseHtml === 'function') {
    return source.parseHtml(html)
  }

  return []
}

export async function fetchRemoteSource(source, filters) {
  try {
    const searchText = getSearchText(filters)
    if (!searchText) {
      return createSourceResult(source.id, source.label, [], {
        skipped: true,
        reason: 'Нужен запрос, бренд или категория для удаленного поиска',
      })
    }

    const url = buildSearchUrl(
      source.baseUrl,
      source.searchPath,
      source.queryParam,
      filters,
    )
    const html = await fetchText(url, { timeoutMs: source.timeoutMs ?? 12000 })
    const offers = dedupeOffers(await parseFromHtml(source, html)).filter((offer) =>
      matchFilters(offer, filters),
    )

    if (!offers.length) {
      return createSourceResult(
        source.id,
        source.label,
        [createFallbackSearchOffer(source.id, source.label, url, searchText)],
        {
          requestUrl: url,
          skipped: false,
          degraded: true,
          reason: 'Карточки не распознаны, добавлена ссылка на поиск на сайте',
        },
      )
    }

    return createSourceResult(source.id, source.label, offers, {
      requestUrl: url,
      skipped: false,
      degraded: false,
    })
  } catch (error) {
    const searchText = getSearchText(filters)

    if (searchText) {
      const fallbackUrl = buildSearchUrl(
        source.baseUrl,
        source.searchPath,
        source.queryParam,
        filters,
      )

      return createSourceResult(
        source.id,
        source.label,
        [createFallbackSearchOffer(source.id, source.label, fallbackUrl, searchText)],
        {
          requestUrl: fallbackUrl,
          degraded: true,
          reason:
            error instanceof Error ? error.message : String(error),
        },
      )
    }

    return createSourceError(source.id, source.label, error)
  }
}
