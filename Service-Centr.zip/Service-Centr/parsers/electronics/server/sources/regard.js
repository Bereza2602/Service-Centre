import { createOffer, normalizeImageUrl, parsePrice, stripTags } from './shared.js'
import { fetchRemoteSource } from './remote-source.js'

const source = {
  id: 'regard',
  label: 'Регард',
  baseUrl: 'https://www.regard.ru',
  searchPath: '/catalog/search',
  queryParam: 'search',
  timeoutMs: 12000,
  parseHtml(html) {
    const offers = []
    const matches = html.matchAll(
      /<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi,
    )

    for (const match of matches) {
      if (!/\/product\//i.test(match[1]) && !/\/goods\//i.test(match[1])) {
        continue
      }

      const title = stripTags(match[2])
      if (!title || title.length < 5) {
        continue
      }

      const blockStart = Math.max(0, match.index - 900)
      const blockEnd = Math.min(html.length, match.index + 2400)
      const block = html.slice(blockStart, blockEnd)
      const price =
        parsePrice(
          block.match(/([\d\s]+)\s?₽/i)?.[1] ||
            block.match(/"price"\s*:\s*"?(.*?)"?(,|})/i)?.[1] ||
            '',
        ) ?? null

      offers.push(
        createOffer(source.id, source.label, {
          title,
          price,
          url: normalizeImageUrl(match[1], source.baseUrl),
          availability: 'С сайта магазина',
          description: 'Результат поиска Regard',
        }),
      )
    }

    return offers
  },
}

export function fetchRegard(filters) {
  return fetchRemoteSource(source, filters)
}
