import { createOffer, normalizeImageUrl, parsePrice, stripTags } from './shared.js'
import { fetchRemoteSource } from './remote-source.js'

const source = {
  id: 'mvideo',
  label: 'М.Видео',
  baseUrl: 'https://www.mvideo.ru',
  searchPath: '/product-list-page',
  queryParam: 'q',
  timeoutMs: 12000,
  parseHtml(html) {
    const offers = []
    const matches = html.matchAll(
      /<a[^>]+class="[^"]*product-title__text[^"]*"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi,
    )

    for (const match of matches) {
      const blockStart = Math.max(0, match.index - 1000)
      const blockEnd = Math.min(html.length, match.index + 2600)
      const block = html.slice(blockStart, blockEnd)
      const price =
        parsePrice(
          block.match(/price__main-value[^>]*>([\d\s]+)</i)?.[1] ||
            block.match(/"price":"?([\d\s]+)"?/i)?.[1] ||
            '',
        ) ?? null

      offers.push(
        createOffer(source.id, source.label, {
          title: stripTags(match[2]),
          price,
          url: normalizeImageUrl(match[1], source.baseUrl),
          availability: 'С сайта магазина',
          description: 'Результат поиска М.Видео',
        }),
      )
    }

    return offers
  },
}

export function fetchMvideo(filters) {
  return fetchRemoteSource(source, filters)
}
