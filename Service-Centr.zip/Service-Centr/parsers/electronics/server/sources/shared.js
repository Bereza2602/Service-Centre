const DEFAULT_HEADERS = {
  'user-agent':
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
  accept:
    'text/html,application/xhtml+xml,application/xml;q=0.9,application/json;q=0.8,*/*;q=0.7',
  'accept-language': 'ru-RU,ru;q=0.9,en;q=0.8',
}

export const SOURCE_IDS = [
  'catalog',
  'yandex-market',
  'regard',
  'chipdip',
]

export const SOURCE_LABELS = {
  catalog: 'Локальная база',
  'yandex-market': 'Яндекс Маркет',
  regard: 'Регард',
  chipdip: 'ChipDip',
}

export const CATEGORY_LABELS = {
  smartphone: 'Смартфоны',
  headphones: 'Наушники',
  laptop: 'Ноутбуки',
  monitor: 'Мониторы',
  smartwatch: 'Умные часы',
  tablet: 'Планшеты',
  console: 'Игровые устройства',
}

export function toPriceText(value) {
  return `${value.toLocaleString('ru-RU')} ₽`
}

export function normalizeText(value = '') {
  return value.trim().toLowerCase()
}

export function toSlug(value = '') {
  return normalizeText(value)
    .replace(/[^a-zа-я0-9]+/gi, '-')
    .replace(/^-+|-+$/g, '')
}

export function parsePrice(value = '') {
  const numeric = String(value).replace(/[^\d]/g, '')
  return numeric ? Number(numeric) : null
}

export function normalizeImageUrl(value = '', baseUrl = '') {
  if (!value) return ''
  if (value.startsWith('http')) return value
  if (value.startsWith('//')) return `https:${value}`
  if (value.startsWith('/') && baseUrl) {
    return new URL(value, baseUrl).toString()
  }

  return value
}

export function decodeHtml(value = '') {
  return value
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/\s+/g, ' ')
    .trim()
}

export function stripTags(value = '') {
  return decodeHtml(value.replace(/<[^>]+>/g, ' '))
}

export function inferBrand(title = '', fallback = '') {
  const source = `${title} ${fallback}`.trim()
  const known = [
    'Apple',
    'Samsung',
    'Xiaomi',
    'Sony',
    'LG',
    'Huawei',
    'Lenovo',
    'ASUS',
    'Dyson',
    'Honor',
    'Realme',
    'Acer',
    'MSI',
  ]

  const match = known.find((brand) =>
    source.toLowerCase().includes(brand.toLowerCase()),
  )

  return match ?? (fallback || 'Не указан')
}

export function inferCategory(title = '', fallback = '') {
  const normalized = normalizeText(`${title} ${fallback}`)

  if (/смартфон|iphone|galaxy|redmi|pixel/.test(normalized)) return 'smartphone'
  if (/ноутбук|laptop|macbook|matebook|zenbook|legion/.test(normalized)) return 'laptop'
  if (/монитор|display|odyssey|ultragear/.test(normalized)) return 'monitor'
  if (/наушник|airpods|buds|headphone|wh-/.test(normalized)) return 'headphones'
  if (/watch|часы/.test(normalized)) return 'smartwatch'
  if (/ipad|tablet|планшет/.test(normalized)) return 'tablet'
  if (/console|playstation|xbox|портал/.test(normalized)) return 'console'

  return 'smartphone'
}

export function matchFilters(product, filters) {
  const normalizedQuery = normalizeText(filters.query)
  const normalizedBrand = normalizeText(filters.brand)
  const normalizedCategory = normalizeText(filters.category)
  const normalizedProductBrand = normalizeText(product.brand)
  const hasPriceMin = Number.isFinite(filters.priceMin)
  const hasPriceMax = Number.isFinite(filters.priceMax)
  const hasPriceFilter = hasPriceMin || hasPriceMax

  if (
    normalizedBrand &&
    normalizedProductBrand !== normalizedBrand &&
    !normalizedProductBrand.includes(normalizedBrand)
  ) {
    return false
  }

  if (normalizedCategory && normalizeText(product.category) !== normalizedCategory) {
    return false
  }

  if (Number.isFinite(product.price)) {
    if (hasPriceMin && product.price < filters.priceMin) {
      return false
    }
    if (hasPriceMax && product.price > filters.priceMax) {
      return false
    }
  }

  if (!normalizedQuery) {
    return true
  }

  const haystack = [
    product.title,
    product.brand,
    product.category,
    product.categoryLabel,
    product.store,
    product.description,
    ...(product.tags ?? []),
  ]
    .join(' ')
    .toLowerCase()

  return haystack.includes(normalizedQuery)
}

export function dedupeOffers(offers) {
  const seen = new Set()

  return offers.filter((offer) => {
    const key = offer.url || `${offer.sourceId}:${offer.title}:${offer.price}`
    if (seen.has(key)) return false
    seen.add(key)
    return true
  })
}

export function sortOffers(offers, sortBy) {
  const sorted = [...offers]

  if (sortBy === 'price-desc') {
    sorted.sort((left, right) => (right.price ?? 0) - (left.price ?? 0))
    return sorted
  }

  if (sortBy === 'title-asc') {
    sorted.sort((left, right) => left.title.localeCompare(right.title, 'ru'))
    return sorted
  }

  sorted.sort((left, right) => {
    const leftPrice = left.price ?? Number.MAX_SAFE_INTEGER
    const rightPrice = right.price ?? Number.MAX_SAFE_INTEGER
    return leftPrice - rightPrice
  })
  return sorted
}

export async function fetchText(url, { timeoutMs = 10000, headers = {} } = {}) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)

  try {
    const response = await fetch(url, {
      headers: { ...DEFAULT_HEADERS, ...headers },
      signal: controller.signal,
    })

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`)
    }

    return response.text()
  } finally {
    clearTimeout(timer)
  }
}

export function createOffer(sourceId, sourceLabel, data) {
  const brand = inferBrand(data.title, data.brand)
  const category = data.category || inferCategory(data.title, data.description)
  const price = data.price ?? null

  return {
    id: data.id || `${sourceId}-${toSlug(data.title)}-${price ?? 'na'}`,
    title: data.title,
    brand,
    category,
    categoryLabel: CATEGORY_LABELS[category] ?? category,
    price,
    priceText: price !== null ? toPriceText(price) : 'Цена не указана',
    store: data.store || sourceLabel,
    availability: data.availability || 'Статус не указан',
    description: data.description || '',
    tags: data.tags || [],
    url: data.url || '',
    imageUrl: data.imageUrl || '',
    sourceId,
    sourceLabel,
  }
}

export function createSourceResult(sourceId, sourceLabel, offers, extra = {}) {
  return {
    sourceId,
    sourceLabel,
    ok: true,
    count: offers.length,
    offers,
    ...extra,
  }
}

export function createFallbackSearchOffer(sourceId, sourceLabel, searchUrl, searchText) {
  return createOffer(sourceId, sourceLabel, {
    id: `${sourceId}-fallback-${toSlug(searchText) || 'search'}`,
    title: `Поиск "${searchText}" на ${sourceLabel}`,
    brand: sourceLabel,
    category: inferCategory(searchText, ''),
    price: null,
    availability: 'Открыть результаты на сайте',
    description: 'Быстрый переход к результатам поиска на выбранном сайте.',
    tags: ['Поиск на сайте'],
    url: searchUrl,
  })
}

export function createSourceError(sourceId, sourceLabel, error) {
  return {
    sourceId,
    sourceLabel,
    ok: false,
    count: 0,
    offers: [],
    error: error instanceof Error ? error.message : String(error),
  }
}

export function getSearchText(filters) {
  return [filters.query, filters.brand, CATEGORY_LABELS[filters.category] || filters.category]
    .filter(Boolean)
    .join(' ')
    .trim()
}

export function parseJsonLdProducts(html, sourceId, sourceLabel, baseUrl) {
  const offers = []
  const scripts = Array.from(
    html.matchAll(/<script[^>]+type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/gi),
    (match) => match[1],
  )

  for (const rawScript of scripts) {
    let parsed
    try {
      parsed = JSON.parse(rawScript)
    } catch {
      continue
    }

    const items = Array.isArray(parsed) ? parsed : [parsed]

    for (const item of items) {
      const candidates = item?.itemListElement || item?.['@graph'] || [item]

      for (const candidate of candidates) {
        const product = candidate?.item || candidate
        const type = product?.['@type']

        if (type !== 'Product') {
          continue
        }

        const price = parsePrice(
          product?.offers?.price ||
            product?.offers?.lowPrice ||
            product?.price ||
            '',
        )
        const url = normalizeImageUrl(product?.url || '', baseUrl)
        const image =
          normalizeImageUrl(
            Array.isArray(product?.image) ? product.image[0] : product?.image || '',
            baseUrl,
          ) || ''

        if (!product?.name || !url) {
          continue
        }

        offers.push(
          createOffer(sourceId, sourceLabel, {
            id: product?.sku || product?.mpn || url,
            title: stripTags(product.name),
            brand:
              typeof product?.brand === 'string'
                ? product.brand
                : product?.brand?.name || '',
            price,
            description: stripTags(product?.description || ''),
            availability: stripTags(product?.offers?.availability || ''),
            url,
            imageUrl: image,
            tags: [],
          }),
        )
      }
    }
  }

  return dedupeOffers(offers)
}
