import { createOffer, normalizeImageUrl, parsePrice, stripTags } from './shared.js'
import { fetchRemoteSource } from './remote-source.js'

const source = {
  id: 'citilink',
  label: 'Ситилинк',
  baseUrl: 'https://www.citilink.ru',
  searchPath: '/search/',
  queryParam: 'text',
  timeoutMs: 12000,
  parseHtml(html) {
    const offers = []
    const matches = html.matchAll(
      /<a[^>]+href="([^"]+)"[^>]*data-meta-name="Snippet__title"[^>]*>([\s\S]*?)<\/a>/gi,
    )

    for (const match of matches) {
      const blockStart = Math.max(0, match.index - 800)
      const blockEnd = Math.min(html.length, match.index + 2400)
      const block = html.slice(blockStart, blockEnd)
      const price =
        parsePrice(
          block.match(/Snippet__price[\s\S]*?>([\d\s]+)</i)?.[1] ||
            block.match(/"price":"?([\d\s]+)"?/i)?.[1] ||
            '',
        ) ?? null

      offers.push(
        createOffer(source.id, source.label, {
          title: stripTags(match[2]),
          price,
          url: normalizeImageUrl(match[1], source.baseUrl),
          availability: 'С сайта магазина',
          description: 'Результат поиска Ситилинк',
        }),
      )
    }

    return offers
  },
}

export function fetchCitilink(filters) {
  return fetchRemoteSource(source, filters)
}
