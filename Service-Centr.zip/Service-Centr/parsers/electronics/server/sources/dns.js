import { createOffer, normalizeImageUrl, parsePrice, stripTags } from './shared.js'
import { fetchRemoteSource } from './remote-source.js'

const source = {
  id: 'dns',
  label: 'DNS',
  baseUrl: 'https://www.dns-shop.ru',
  searchPath: '/search/',
  queryParam: 'q',
  timeoutMs: 12000,
  parseHtml(html) {
    const offers = []
    const matches = html.matchAll(
      /<a[^>]+class="[^"]*catalog-product__name[^"]*"[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi,
    )

    for (const match of matches) {
      const blockStart = Math.max(0, match.index - 800)
      const blockEnd = Math.min(html.length, match.index + 2600)
      const block = html.slice(blockStart, blockEnd)
      const price =
        parsePrice(
          block.match(/catalog-product__price[^>]*>([\s\S]*?)<\/div>/i)?.[1] ||
            block.match(/data-price="([\d\s]+)"/i)?.[1] ||
            '',
        ) ?? null

      offers.push(
        createOffer(source.id, source.label, {
          title: stripTags(match[2]),
          price,
          url: normalizeImageUrl(match[1], source.baseUrl),
          availability: 'С сайта магазина',
          description: 'Результат поиска DNS',
        }),
      )
    }

    return offers
  },
}

export function fetchDns(filters) {
  return fetchRemoteSource(source, filters)
}
