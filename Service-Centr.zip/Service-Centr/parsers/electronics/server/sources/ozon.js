import { createOffer, normalizeImageUrl, parsePrice, stripTags } from './shared.js'
import { fetchRemoteSource } from './remote-source.js'

const source = {
  id: 'ozon',
  label: 'Ozon',
  baseUrl: 'https://www.ozon.ru',
  searchPath: '/search/',
  queryParam: 'text',
  timeoutMs: 12000,
  parseHtml(html) {
    const offers = []
    const matches = html.matchAll(
      /<a[^>]+href="([^"]+)"[^>]*title="([^"]+)"[^>]*>/gi,
    )

    for (const match of matches) {
      if (!/\/product\//i.test(match[1])) {
        continue
      }

      const blockStart = Math.max(0, match.index - 1000)
      const blockEnd = Math.min(html.length, match.index + 2800)
      const block = html.slice(blockStart, blockEnd)
      const price =
        parsePrice(
          block.match(/"price":"?([\d\s]+)"?/i)?.[1] ||
            block.match(/[\>"]([\d\s]+)\s?₽</i)?.[1] ||
            '',
        ) ?? null

      offers.push(
        createOffer(source.id, source.label, {
          title: stripTags(match[2]),
          price,
          url: normalizeImageUrl(match[1], source.baseUrl),
          availability: 'С сайта магазина',
          description: 'Результат поиска Ozon',
        }),
      )
    }

    return offers
  },
}

export function fetchOzon(filters) {
  return fetchRemoteSource(source, filters)
}
