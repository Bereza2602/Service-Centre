import { createOffer, normalizeImageUrl, parsePrice, stripTags } from './shared.js'
import { fetchRemoteSource } from './remote-source.js'

const source = {
  id: 'yandex-market',
  label: 'Яндекс Маркет',
  baseUrl: 'https://market.yandex.ru',
  searchPath: '/search',
  queryParam: 'text',
  timeoutMs: 12000,
  parseHtml(html) {
    const offers = []
    const matches = html.matchAll(
      /<a[^>]+href="([^"]+)"[^>]*data-auto="snippet-title"[\s\S]*?<span[^>]*>([\s\S]*?)<\/span>/gi,
    )

    for (const match of matches) {
      const blockStart = Math.max(0, match.index - 1200)
      const blockEnd = Math.min(html.length, match.index + 3200)
      const block = html.slice(blockStart, blockEnd)
      const price =
        parsePrice(
          block.match(/"price":"?([\d\s]+)"?/i)?.[1] ||
            block.match(/data-auto="snippet-price-current"[\s\S]*?>([\d\s]+)</i)?.[1] ||
            '',
        ) ?? null

      offers.push(
        createOffer(source.id, source.label, {
          title: stripTags(match[2]),
          price,
          url: normalizeImageUrl(match[1], source.baseUrl),
          availability: 'С сайта магазина',
          description: 'Результат поиска Яндекс Маркета',
        }),
      )
    }

    return offers
  },
}

export function fetchYandexMarket(filters) {
  return fetchRemoteSource(source, filters)
}
