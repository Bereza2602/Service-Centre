import { createOffer, normalizeImageUrl, parsePrice, stripTags } from './shared.js'
import { fetchRemoteSource } from './remote-source.js'

const source = {
  id: 'pleer',
  label: 'Плеер.ру',
  baseUrl: 'https://www.pleer.ru',
  searchPath: '/search_',
  queryParam: 'text',
  timeoutMs: 12000,
  parseHtml(html) {
    const offers = []
    const matches = html.matchAll(
      /<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi,
    )

    for (const match of matches) {
      if (!/\/product_/i.test(match[1]) && !/\/_.*html/i.test(match[1])) {
        continue
      }

      const title = stripTags(match[2])
      if (!title || title.length < 5) {
        continue
      }

      const blockStart = Math.max(0, match.index - 900)
      const blockEnd = Math.min(html.length, match.index + 2200)
      const block = html.slice(blockStart, blockEnd)
      const price =
        parsePrice(
          block.match(/([\d\s]+)\s?руб/i)?.[1] ||
            block.match(/([\d\s]+)\s?₽/i)?.[1] ||
            '',
        ) ?? null

      offers.push(
        createOffer(source.id, source.label, {
          title,
          price,
          url: normalizeImageUrl(match[1], source.baseUrl),
          availability: 'С сайта магазина',
          description: 'Результат поиска Плеер.ру',
        }),
      )
    }

    return offers
  },
}

export function fetchPleer(filters) {
  return fetchRemoteSource(source, filters)
}
