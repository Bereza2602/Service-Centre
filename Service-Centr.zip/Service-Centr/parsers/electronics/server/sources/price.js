import { createOffer, normalizeImageUrl, parsePrice, stripTags } from './shared.js'
import { fetchRemoteSource } from './remote-source.js'

const source = {
  id: 'price',
  label: 'Price.ru',
  baseUrl: 'https://price.ru',
  searchPath: '/search/',
  queryParam: 'text',
  timeoutMs: 12000,
  parseHtml(html) {
    const offers = []
    const matches = html.matchAll(
      /<a[^>]+href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/gi,
    )

    for (const match of matches) {
      if (!/\/offers\//i.test(match[1]) && !/\/product\//i.test(match[1])) {
        continue
      }

      const title = stripTags(match[2])
      if (!title || title.length < 6) {
        continue
      }

      const blockStart = Math.max(0, match.index - 900)
      const blockEnd = Math.min(html.length, match.index + 2400)
      const block = html.slice(blockStart, blockEnd)
      const price =
        parsePrice(
          block.match(/"price"\s*:\s*"?(.*?)"?(,|})/i)?.[1] ||
            block.match(/([\d\s]+)\s?₽/i)?.[1] ||
            '',
        ) ?? null

      offers.push(
        createOffer(source.id, source.label, {
          title,
          price,
          url: normalizeImageUrl(match[1], source.baseUrl),
          availability: 'С агрегатора цен',
          description: 'Результат поиска Price.ru',
        }),
      )
    }

    return offers
  },
}

export function fetchPrice(filters) {
  return fetchRemoteSource(source, filters)
}
