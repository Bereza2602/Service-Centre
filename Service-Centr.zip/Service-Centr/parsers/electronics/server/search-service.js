import { getLocalCatalogOffers } from './electronics-catalog.js'
import { fetchChipDip } from './sources/chipdip.js'
import { fetchRegard } from './sources/regard.js'
import {
  SOURCE_IDS,
  SOURCE_LABELS,
  dedupeOffers,
  matchFilters,
  sortOffers,
} from './sources/shared.js'
import { fetchYandexMarket } from './sources/yandex-market.js'

const SEARCH_HANDLERS = {
  catalog: async (filters) => getLocalCatalogOffers(filters),
  'yandex-market': fetchYandexMarket,
  regard: fetchRegard,
  chipdip: fetchChipDip,
}

export function parseRequestedSources(value = '') {
  const requested = value
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean)

  if (!requested.length) {
    return SOURCE_IDS
  }

  return requested.filter((item) => SOURCE_IDS.includes(item))
}

export async function searchElectronics(filters) {
  const requestedSources = parseRequestedSources(filters.sources)
  const results = await Promise.all(
    requestedSources.map(async (sourceId) => {
      const handler = SEARCH_HANDLERS[sourceId]
      if (!handler) {
        return {
          sourceId,
          sourceLabel: SOURCE_LABELS[sourceId] ?? sourceId,
          ok: false,
          count: 0,
          offers: [],
          error: 'Источник не поддерживается',
        }
      }

      return handler(filters)
    }),
  )

  const offers = sortOffers(
    dedupeOffers(
      results.flatMap((result) => result.offers).filter((offer) =>
        matchFilters(offer, filters),
      ),
    ),
    filters.sortBy,
  )

  return {
    total: offers.length,
    filtered: offers.length,
    source: 'Мульти-источниковый поиск электроники',
    filters: {
      query: filters.query,
      brand: filters.brand,
      category: filters.category,
      priceMin: filters.priceMin,
      priceMax: filters.priceMax,
      sortBy: filters.sortBy,
      sources: requestedSources,
    },
    meta: {
      availableSources: SOURCE_IDS.map((value) => ({
        value,
        label: SOURCE_LABELS[value] ?? value,
      })),
      sourceStatuses: results.map((result) => ({
        sourceId: result.sourceId,
        sourceLabel: result.sourceLabel,
        ok: result.ok,
        count: result.count,
        skipped: result.skipped ?? false,
        degraded: result.degraded ?? false,
        reason: result.degraded
          ? 'Открываем поиск на сайте источника'
          : result.reason || result.error || '',
      })),
    },
    offers,
  }
}
