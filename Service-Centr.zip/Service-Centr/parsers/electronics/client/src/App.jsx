import { useMemo, useState, useTransition } from 'react'
import './App.css'

const BRAND_OPTIONS = [
  { value: '', label: 'Все бренды' },
  { value: 'Apple', label: 'Apple' },
  { value: 'Samsung', label: 'Samsung' },
  { value: 'Xiaomi', label: 'Xiaomi' },
  { value: 'Sony', label: 'Sony' },
  { value: 'LG', label: 'LG' },
  { value: 'Huawei', label: 'Huawei' },
  { value: 'Lenovo', label: 'Lenovo' },
  { value: 'ASUS', label: 'ASUS' },
]

const CATEGORY_OPTIONS = [
  { value: '', label: 'Все категории' },
  { value: 'smartphone', label: 'Смартфоны' },
  { value: 'headphones', label: 'Наушники' },
  { value: 'laptop', label: 'Ноутбуки' },
  { value: 'monitor', label: 'Мониторы' },
  { value: 'smartwatch', label: 'Умные часы' },
  { value: 'tablet', label: 'Планшеты' },
  { value: 'console', label: 'Игровые устройства' },
]

const SOURCE_OPTIONS = [
  { value: 'catalog', label: 'Локальная база', hint: 'Стабильно' },
  { value: 'yandex-market', label: 'Яндекс Маркет', hint: 'Стабильно' },
  { value: 'regard', label: 'Регард', hint: 'Стабильно' },
  { value: 'chipdip', label: 'ChipDip', hint: 'Стабильно' },
  { value: 'price', label: 'Price.ru', hint: 'Условно стабильно' },
  { value: 'dns', label: 'DNS', hint: 'Часто блокирует' },
  { value: 'citilink', label: 'Ситилинк', hint: 'Часто rate limit' },
  { value: 'mvideo', label: 'М.Видео', hint: 'Нестабильная выдача' },
  { value: 'ozon', label: 'Ozon', hint: 'Часто блокирует' },
  { value: 'pleer', label: 'Плеер.ру', hint: 'Нестабильно' },
]

const SORT_OPTIONS = [
  { value: 'price-asc', label: 'Сначала дешевле' },
  { value: 'price-desc', label: 'Сначала дороже' },
  { value: 'title-asc', label: 'По названию' },
]

const DEFAULT_FILTERS = {
  query: '',
  brand: '',
  category: '',
  priceMin: '',
  priceMax: '',
  sortBy: 'price-asc',
  sources: SOURCE_OPTIONS.map((source) => source.value),
}

function buildQuery(filters) {
  const searchParams = new URLSearchParams()

  if (filters.query.trim()) {
    searchParams.set('query', filters.query.trim())
  }

  if (filters.brand) {
    searchParams.set('brand', filters.brand)
  }

  if (filters.category) {
    searchParams.set('category', filters.category)
  }

  if (filters.priceMin.trim()) {
    searchParams.set('priceMin', filters.priceMin.trim())
  }

  if (filters.priceMax.trim()) {
    searchParams.set('priceMax', filters.priceMax.trim())
  }

  searchParams.set('sortBy', filters.sortBy)
  searchParams.set('sources', filters.sources.join(','))

  return searchParams.toString()
}

function toggleSource(setFilters, sourceId) {
  setFilters((current) => ({
    ...current,
    sources: current.sources.includes(sourceId)
      ? current.sources.filter((value) => value !== sourceId)
      : [...current.sources, sourceId],
  }))
}

function getFallbackLabel(offer) {
  return `${offer.brand} · ${offer.sourceLabel}`.trim()
}

function App() {
  const [filters, setFilters] = useState(DEFAULT_FILTERS)
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')
  const [isPending, startTransition] = useTransition()

  const queryPreview = useMemo(() => buildQuery(filters), [filters])

  async function handleSearch(event) {
    event.preventDefault()
    setError('')

    try {
      const response = await fetch(`/api/search?${buildQuery(filters)}`)
      const payload = await response.json()

      if (!response.ok) {
        throw new Error(payload.details || payload.error || 'Search failed')
      }

      startTransition(() => {
        setResult(payload)
      })
    } catch (requestError) {
      setResult(null)
      setError(
        requestError instanceof Error
          ? requestError.message
          : 'Не удалось получить данные',
      )
    }
  }

  return (
    <main className="shell">
      <section className="hero-panel">
        <div className="hero-copy">
          <p className="eyebrow">Electronics Parser</p>
          <h1>Поиск электроники сразу по нескольким магазинам</h1>
          <p className="lead">
            Парсер собирает товары из агрегаторов и магазинов, фильтрует по цене,
            бренду и категории, а затем показывает единый список. Если один
            источник не отдает карточки напрямую, система добавляет рабочий переход
            на поиск на этом сайте и не ломает весь результат.
          </p>

          <div className="status-row">
            <span className="status-pill">Поиск сразу по всем источникам</span>
            <span className="status-pill">Переход на сайт при защите магазина</span>
            <span className="status-pill">Проект не падает из-за одного сайта</span>
          </div>
        </div>

        <form className="search-panel" onSubmit={handleSearch}>
          <div className="field">
            <label htmlFor="query">Что ищем</label>
            <input
              id="query"
              value={filters.query}
              onChange={(event) =>
                setFilters((current) => ({
                  ...current,
                  query: event.target.value,
                }))
              }
              placeholder="Например: iPhone, смартфон, монитор, видеокарта"
            />
            <small>
              Для удаленных источников лучше указывать поисковую фразу, бренд или категорию.
            </small>
          </div>

          <div className="field-grid">
            <div className="field">
              <label htmlFor="brand">Бренд</label>
              <div className="select-wrap">
                <select
                  id="brand"
                  value={filters.brand}
                  onChange={(event) =>
                    setFilters((current) => ({
                      ...current,
                      brand: event.target.value,
                    }))
                  }
                >
                  {BRAND_OPTIONS.map((option) => (
                    <option key={option.value || 'all'} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
                <span className="select-arrow">▼</span>
              </div>
            </div>

            <div className="field">
              <label htmlFor="category">Категория</label>
              <div className="select-wrap">
                <select
                  id="category"
                  value={filters.category}
                  onChange={(event) =>
                    setFilters((current) => ({
                      ...current,
                      category: event.target.value,
                    }))
                  }
                >
                  {CATEGORY_OPTIONS.map((option) => (
                    <option key={option.value || 'all'} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
                <span className="select-arrow">▼</span>
              </div>
            </div>
          </div>

          <div className="field-grid">
            <div className="field">
              <label htmlFor="priceMin">Цена от, ₽</label>
              <input
                id="priceMin"
                inputMode="numeric"
                value={filters.priceMin}
                onChange={(event) =>
                  setFilters((current) => ({
                    ...current,
                    priceMin: event.target.value.replace(/[^\d]/g, ''),
                  }))
                }
                placeholder="10000"
              />
            </div>

            <div className="field">
              <label htmlFor="priceMax">Цена до, ₽</label>
              <input
                id="priceMax"
                inputMode="numeric"
                value={filters.priceMax}
                onChange={(event) =>
                  setFilters((current) => ({
                    ...current,
                    priceMax: event.target.value.replace(/[^\d]/g, ''),
                  }))
                }
                placeholder="80000"
              />
            </div>
          </div>

          <div className="field">
            <label htmlFor="sortBy">Сортировка</label>
            <div className="select-wrap">
              <select
                id="sortBy"
                value={filters.sortBy}
                onChange={(event) =>
                  setFilters((current) => ({
                    ...current,
                    sortBy: event.target.value,
                  }))
                }
              >
                {SORT_OPTIONS.map((option) => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </select>
              <span className="select-arrow">▼</span>
            </div>
          </div>

          <div className="field">
            <label>Источники</label>
            <div className="sources-grid">
              {SOURCE_OPTIONS.map((source) => (
                <button
                  key={source.value}
                  type="button"
                  className={
                    filters.sources.includes(source.value)
                      ? 'source-chip active'
                      : 'source-chip'
                  }
                  onClick={() => toggleSource(setFilters, source.value)}
                >
                  <span>{source.label}</span>
                  <small>{source.hint}</small>
                </button>
              ))}
            </div>
          </div>

          <button
            className="submit-button"
            type="submit"
            disabled={isPending || !filters.sources.length}
          >
            {isPending ? 'Собираю предложения...' : 'Найти технику'}
          </button>

          <div className="query-preview">
            <span>API запрос:</span>
            <code>/api/search?{queryPreview}</code>
          </div>
        </form>
      </section>

      <section className="results-panel">
        <div className="results-header">
          <div>
            <p className="section-label">Результаты</p>
            <h2>Товары из выбранных источников</h2>
          </div>

          {result ? (
            <div className="results-meta">
              <span>Найдено: {result.filtered}</span>
              <span>Источников: {result.filters.sources.length}</span>
              <span>Режим: мульти-поиск</span>
            </div>
          ) : null}
        </div>

        {error ? <div className="message error">{error}</div> : null}

        {!result && !error ? (
          <div className="message empty">
            Выберите источники и задайте фильтры. Для агрегаторов и магазинов лучше
            вводить поисковый запрос, например: iPhone, смартфон или монитор.
          </div>
        ) : null}

        {result?.meta?.sourceStatuses?.length ? (
          <div className="source-status-grid">
            {result.meta.sourceStatuses.map((status) => (
              <article
                key={status.sourceId}
                className={status.ok ? 'source-status ok' : 'source-status error'}
              >
                <strong>{status.sourceLabel}</strong>
                <span>
                  {status.ok
                    ? status.skipped
                      ? `Пропущен: ${status.reason}`
                      : status.degraded
                        ? `Поиск на сайте: ${status.count}`
                        : `Товаров: ${status.count}`
                    : `Ошибка: ${status.reason}`}
                </span>
              </article>
            ))}
          </div>
        ) : null}

        {result && !result.offers.length ? (
          <div className="message empty">
            По этим параметрам товары не найдены. Попробуйте поменять запрос,
            расширить диапазон цен или включить больше источников.
          </div>
        ) : null}

        <div className="cards-grid">
          {result?.offers.map((offer) => (
            <article className="offer-card" key={offer.id}>
              <div className="offer-image-wrap">
                <div className="offer-image fallback">
                  <span>{getFallbackLabel(offer)}</span>
                </div>
                <div className="offer-price">{offer.priceText}</div>
              </div>

              <div className="offer-body">
                <div className="offer-main">
                  <div className="offer-topline">
                    <span className="offer-brand">{offer.brand}</span>
                    <span className="offer-store">{offer.store}</span>
                  </div>

                  <h3>{offer.title}</h3>
                  <p className="offer-address">
                    {offer.categoryLabel} · {offer.sourceLabel}
                  </p>
                  <p className="offer-description">{offer.description}</p>
                </div>

                <div className="offer-footer">
                  <div className="tag-row">
                    <span className="tag availability">{offer.availability}</span>
                    {(offer.tags || []).map((tag) => (
                      <span className="tag" key={`${offer.id}-${tag}`}>
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div className="offer-actions">
                    <span className="offer-date">Цена: {offer.priceText}</span>
                    <a href={offer.url} target="_blank" rel="noreferrer">
                      Открыть карточку
                    </a>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </main>
  )
}

export default App
