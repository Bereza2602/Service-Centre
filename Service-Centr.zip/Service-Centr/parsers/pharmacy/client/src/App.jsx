import { useEffect, useMemo, useState, useTransition } from 'react'
import './App.css'

const CITY_OPTIONS = [
  { value: 'moskva', label: 'Москва' },
  { value: 'sankt-peterburg', label: 'Санкт-Петербург' },
  { value: 'ekaterinburg', label: 'Екатеринбург' },
  { value: 'kazan', label: 'Казань' },
  { value: 'novosibirsk', label: 'Новосибирск' },
  { value: 'orenburg', label: 'Оренбург' },
  { value: 'samara', label: 'Самара' },
  { value: 'ufa', label: 'Уфа' },
  { value: 'chelyabinsk', label: 'Челябинск' },
  { value: 'rostov', label: 'Ростов-на-Дону' },
]

const SORT_OPTIONS = [
  { value: 'price-asc', label: 'Сначала дешевле' },
  { value: 'distance-asc', label: 'Ближе к центру' },
  { value: 'stock-desc', label: 'Больше в наличии' },
]

const SOURCE_OPTIONS = [
  { value: 'uteka', label: 'Ютека' },
  { value: 'apteka-ru', label: 'Apteka.ru' },
  { value: 'eapteka', label: 'ЕАПТЕКА' },
  { value: 'zdravcity', label: 'Здравсити' },
  { value: 'vita', label: 'Вита' },
  { value: 'ozerki', label: 'Озерки' },
  { value: 'rigla', label: 'Ригла' },
  { value: 'planetazdorovo', label: 'Планета Здоровья' },
  { value: 'farmland', label: 'Фармленд' },
  { value: 'aloe', label: 'Алоэ' },
  { value: 'nadezhda', label: 'Надежда' },
  { value: 'implozia', label: 'Имплозия' },
  { value: 'vitaminka', label: 'Витаминка' },
  { value: 'melodia-zdorovia', label: 'Мелодия здоровья' },
  { value: 'zhivika', label: 'Живика' },
  { value: 'apteka66', label: 'Аптека66' },
]

const DEFAULT_FILTERS = {
  city: 'ekaterinburg',
  query: 'нурофен',
  maxPrice: '700',
  sortBy: 'price-asc',
  onlyInStock: true,
  limit: '50',
  sources: SOURCE_OPTIONS.map((option) => option.value),
}

function buildQuery(filters) {
  const params = new URLSearchParams()
  params.set('city', filters.city)
  params.set('query', filters.query.trim())
  params.set('sortBy', filters.sortBy)

  if (filters.maxPrice.trim()) {
    params.set('maxPrice', filters.maxPrice.trim())
  }

  if (filters.onlyInStock) {
    params.set('onlyInStock', 'true')
  }

  if (filters.limit.trim()) {
    params.set('limit', filters.limit.trim())
  }

  if (filters.sources.length) {
    params.set('sources', filters.sources.join(','))
  }

  return params.toString()
}

function getBadgeTone(value) {
  if (value === 'В наличии') return 'green'
  if (value === 'Заканчивается') return 'amber'
  return 'slate'
}

function App() {
  const [filters, setFilters] = useState(DEFAULT_FILTERS)
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')
  const [isPending, startTransition] = useTransition()

  const queryPreview = useMemo(() => buildQuery(filters), [filters])

  function toggleSource(sourceId) {
    setFilters((current) => ({
      ...current,
      sources: current.sources.includes(sourceId)
        ? current.sources.filter((value) => value !== sourceId)
        : [...current.sources, sourceId],
    }))
  }

  async function runSearch(activeFilters) {
    setError('')

    try {
      const response = await fetch(`/api/search?${buildQuery(activeFilters)}`)
      const payload = await response.json()

      if (!response.ok) {
        throw new Error(payload.details || payload.error || 'Не удалось получить данные')
      }

      startTransition(() => {
        setResult(payload)
      })
    } catch (requestError) {
      setResult(null)
      setError(
        requestError instanceof Error
          ? requestError.message
          : 'Не удалось получить данные по аптекам',
      )
    }
  }

  function handleSearch(event) {
    event.preventDefault()
    runSearch(filters)
  }

  useEffect(() => {
    runSearch(DEFAULT_FILTERS)
  }, [])

  return (
    <main className="shell">
      <section className="hero-panel">
        <div className="hero-copy">
          <p className="eyebrow">ParserApteka</p>
          <h1>Живой парсер аптек для поиска лекарств по лучшей цене</h1>
          <p className="lead">
            Сервис ищет лекарство по городу, показывает точные цены из базы, реальные
            аптеки, телефоны, наличие, расстояние и быструю ссылку на карту.
          </p>

          <div className="status-row">
            <span className="status-pill">API: /api/search</span>
            <span className="status-pill">Сценарий: поиск дешёвого лекарства</span>
            <span className="status-pill">Карты: Яндекс + Google</span>
            <span className="status-pill">Режим: демо-база для подключения live-данных</span>
            <span className="status-pill">Приоритет: Ютека → Apteka.ru → ЕАПТЕКА → Здравсити</span>
          </div>

          <div className="hero-metrics">
            <article>
              <strong>{result?.meta.totalOffers ?? 128}</strong>
              <span>аптек в выборке</span>
            </article>
            <article>
              <strong>{result?.meta.cheapestPriceText ?? 'от 119 ₽'}</strong>
              <span>лучшая найденная цена</span>
            </article>
            <article>
              <strong>{result?.meta.citiesCovered ?? 5}</strong>
              <span>городов в демо-базе</span>
            </article>
          </div>
        </div>

        <form className="search-panel" onSubmit={handleSearch}>
          <div className="field">
            <label htmlFor="query">Лекарство или товар</label>
            <input
              id="query"
              value={filters.query}
              onChange={(event) =>
                setFilters((current) => ({
                  ...current,
                  query: event.target.value,
                }))
              }
              placeholder="Например: Нурофен, Аквадетрим, Омега-3"
            />
          </div>

          <div className="field">
            <label htmlFor="city">Город</label>
            <div className="select-wrap">
              <select
                id="city"
                value={filters.city}
                onChange={(event) =>
                  setFilters((current) => ({
                    ...current,
                    city: event.target.value,
                  }))
                }
              >
                {CITY_OPTIONS.map((city) => (
                  <option key={city.value} value={city.value}>
                    {city.label}
                  </option>
                ))}
              </select>
              <span className="select-arrow">▼</span>
            </div>
          </div>

          <div className="field split">
            <div>
              <label htmlFor="maxPrice">Цена до, ₽</label>
              <input
                id="maxPrice"
                inputMode="numeric"
                value={filters.maxPrice}
                onChange={(event) =>
                  setFilters((current) => ({
                    ...current,
                    maxPrice: event.target.value.replace(/[^\d]/g, ''),
                  }))
                }
                placeholder="700"
              />
            </div>

            <div>
              <label htmlFor="sortBy">Сортировка</label>
              <div className="select-wrap">
                <select
                  id="sortBy"
                  value={filters.sortBy}
                  onChange={(event) =>
                    setFilters((current) => ({
                      ...current,
                      sortBy: event.target.value,
                    }))
                  }
                >
                  {SORT_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
                <span className="select-arrow">▼</span>
              </div>
            </div>
          </div>

          <div className="field split">
            <div>
              <label htmlFor="limit">Сколько результатов</label>
              <input
                id="limit"
                inputMode="numeric"
                value={filters.limit}
                onChange={(event) =>
                  setFilters((current) => ({
                    ...current,
                    limit: event.target.value.replace(/[^\d]/g, ''),
                  }))
                }
                placeholder="50"
              />
            </div>
            <div className="field">
              <span className="field-label-inline">Источники</span>
              <div className="source-grid">
                {SOURCE_OPTIONS.map((option) => (
                  <button
                    key={option.value}
                    type="button"
                    className={
                      filters.sources.includes(option.value)
                        ? 'source-chip active'
                        : 'source-chip'
                    }
                    onClick={() => toggleSource(option.value)}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <label className="check-row">
            <input
              type="checkbox"
              checked={filters.onlyInStock}
              onChange={(event) =>
                setFilters((current) => ({
                  ...current,
                  onlyInStock: event.target.checked,
                }))
              }
            />
            <span>Показывать только то, что есть в наличии сейчас</span>
          </label>

          <button className="submit-button" type="submit" disabled={isPending}>
            {isPending ? 'Ищу аптеки...' : 'Найти лекарство'}
          </button>

          <div className="query-preview">
            <span>Запрос:</span>
            <code>/api/search?{queryPreview}</code>
          </div>
        </form>
      </section>

      <section className="results-panel">
        <div className="results-header">
          <div>
            <p className="section-label">Результаты</p>
            <h2>Аптеки, цены и контакты</h2>
          </div>

          {result ? (
            <div className="results-meta">
              <span>Найдено аптек: {result.meta.totalOffers}</span>
              <span>Лучшая цена: {result.meta.cheapestPriceText}</span>
              <span>Средняя цена: {result.meta.averagePriceText}</span>
            </div>
          ) : null}
        </div>

        {result ? (
          <div className="message empty">
            {result.meta.regionalNote}
            {' '}Обязательные поля для источников: {result.meta.requiredSourceFields.join(', ')}.
            {' '}Режим: {result.meta.parserMode}
          </div>
        ) : null}

        {result?.meta.sourceSummary?.length ? (
          <div className="source-summary-grid">
            {result.meta.sourceSummary.map((source) => (
              <article className="source-summary-card" key={source.id}>
                <p className="section-label">{source.name}</p>
                <strong>{source.totalOffers}</strong>
                <span>результатов</span>
                <span>минимум: {source.cheapestPriceText}</span>
                <span>домен: {source.domains.join(', ')}</span>
              </article>
            ))}
          </div>
        ) : null}

        {error ? <div className="message error">{error}</div> : null}

        {!result && !error ? (
          <div className="message empty">
            Введите название лекарства, выберите город и нажмите «Найти лекарство».
          </div>
        ) : null}

        {result && !result.offers.length ? (
          <div className="message empty">
            По этому запросу ничего не найдено. Попробуйте другой город, товар или
            увеличьте лимит по цене.
          </div>
        ) : null}

        {result?.heroOffer ? (
          <article className="best-deal-card">
            <div>
              <p className="section-label">Лучшая находка</p>
              <h3>{result.heroOffer.productName}</h3>
              <p className="best-deal-text">
                {result.heroOffer.pharmacyName}, {result.heroOffer.address}
              </p>
            </div>
            <div className="best-deal-side">
              <strong>{result.heroOffer.priceText}</strong>
              <span>{result.heroOffer.phone}</span>
              <a href={result.heroOffer.mapUrl} target="_blank" rel="noreferrer">
                Открыть на карте
              </a>
            </div>
          </article>
        ) : null}

        <div className="cards-grid">
          {result?.offers.map((offer) => (
            <article className="offer-card" key={offer.id}>
              <div className="offer-topline">
                <div>
                  <p className="offer-network">{offer.network}</p>
                  <h3>{offer.productName}</h3>
                </div>
                <div className="offer-price-block">
                  <strong>{offer.priceText}</strong>
                  <span>{offer.pricePerUnit}</span>
                </div>
              </div>

              <div className="tag-row">
                <span className={`tag ${getBadgeTone(offer.stockLabel)}`}>
                  {offer.stockLabel}
                </span>
                <span className="tag">{offer.form}</span>
                <span className="tag">{offer.distanceText}</span>
                {offer.source ? <span className="tag">{offer.source.name}</span> : null}
                {offer.missingFields?.length ? (
                  <span className="tag amber">Не хватает полей: {offer.missingFields.length}</span>
                ) : (
                  <span className="tag green">Поля полные</span>
                )}
                {offer.isOpenNow ? <span className="tag green">Открыта сейчас</span> : null}
              </div>

              <div className="offer-details">
                <p><strong>Аптека:</strong> {offer.pharmacyName}</p>
                <p><strong>Адрес:</strong> {offer.address}</p>
                <p><strong>Телефон:</strong> <a href={`tel:${offer.phoneRaw}`}>{offer.phone}</a></p>
                <p><strong>Часы работы:</strong> {offer.schedule}</p>
                {offer.source ? <p><strong>Источник:</strong> {offer.source.name}</p> : null}
                {offer.source ? <p><strong>Роль источника:</strong> {offer.source.strengths.join(', ')}</p> : null}
              </div>

              <p className="offer-description">{offer.description}</p>

              <div className="offer-actions">
                {offer.website ? (
                  <a href={offer.website} target="_blank" rel="noreferrer">
                    Сайт аптеки
                  </a>
                ) : null}
                <a href={offer.mapUrl} target="_blank" rel="noreferrer">
                  Яндекс.Карты
                </a>
                <a href={offer.googleMapsUrl} target="_blank" rel="noreferrer">
                  Google Maps
                </a>
              </div>
            </article>
          ))}
        </div>
      </section>
    </main>
  )
}

export default App
