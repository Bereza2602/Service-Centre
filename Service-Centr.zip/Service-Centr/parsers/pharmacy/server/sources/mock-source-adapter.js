import { SOURCE_OFFERS } from '../data/source-offers.js'
import { buildCatalogOffersForSource } from '../data/catalog.js'
import { normalizeSourcePayload } from '../source-config.js'

export function createMockSourceAdapter(config) {
  return {
    ...config,
    async search(context) {
      const offers = [
        ...(SOURCE_OFFERS[config.id] ?? []),
        ...buildCatalogOffersForSource(config.id),
      ].map((offer) =>
        normalizeSourcePayload(offer, config.id),
      )

      return {
        source: config,
        offers,
        diagnostics: {
          adapter: 'mock',
          city: context.city,
          query: context.query,
          domain: config.domains[0],
          liveReady: true,
        },
      }
    },
  }
}
