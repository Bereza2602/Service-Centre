import * as cheerio from 'cheerio';
import { normalizeSourcePayload } from '../source-config.js';

const SEARCH_URL = 'https://www.eapteka.ru/search/';

async function fetchEaptekaProducts(query, city) {
  const url = SEARCH_URL + '?q=' + encodeURIComponent(query);

  const resp = await fetch(url, {
    headers: {
      'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'accept': 'text/html,application/xhtml+xml',
      'accept-language': 'ru-RU,ru;q=0.9',
    },
    signal: AbortSignal.timeout(10000),
  });

  const html = await resp.text();
  const $ = cheerio.load(html);
  const seen = new Set();
  const products = [];

  $('[class*="listing-card"]').each((i, el) => {
    const $el = $(el);

    // Find the primary product link (with /goods/ in href)
    const goodsLink = $el.find('a[href*="/goods/"]').first();
    if (!goodsLink.length) return;
    const href = goodsLink.attr('href') || '';
    const productUrl = href.startsWith('http') ? href : 'https://www.eapteka.ru' + href;

    // Skip non-product links (analogs, brand pages, etc.)
    if (!href.match(/^\/goods\/id\d+/)) return;

    if (seen.has(productUrl)) return;
    seen.add(productUrl);

    let name = goodsLink.text().trim();
    if (!name) {
      name = $el.find('img').first().attr('alt') || '';
    }
    name = name.replace(/^Купить\s+/i, '').replace(/\s+цена\s*$/i, '').trim();
    if (!name || /^\d+$/.test(name)) return;

    const priceEl = $el.find('[class*="price-new"]').first();
    const priceText = priceEl.text().trim();
    const price = parseInt(priceText.replace(/[^\d]/g, ''));
    if (!price) return;

    const oldPriceEl = $el.find('[class*="price-old"]').first();
    const oldPriceText = oldPriceEl.text().trim();
    const oldPrice = parseInt(oldPriceText.replace(/[^\d]/g, ''));

    const stockEl = $el.find('[class*="available"]').first();
    const stockText = stockEl.text().trim().toLowerCase();
    const inStock = !stockText.includes('нет') && !stockText.includes('отсутствует');

    products.push({
      productName: name.slice(0, 150),
      price,
      oldPrice: oldPrice || undefined,
      stockLabel: inStock ? 'В наличии' : 'Под заказ',
      stockCount: inStock ? 5 : 0,
      pharmacyName: 'ЕАПТЕКА (онлайн)',
      address: 'Доставка по всей России',
      phone: '8 (800) 555-55-55',
      city: city || 'ekaterinburg',
      lat: 55.7558,
      lon: 37.6173,
      website: 'https://www.eapteka.ru',
      reserveUrl: productUrl,
      prescription: false,
      distanceKm: 0,
      isOpenNow: true,
    });
  });

  return products;
}

export function createLiveEaptekaAdapter(config) {
  return {
    ...config,
    async search(context) {
      const query = (context.query || '').trim();
      if (!query) {
        return {
          source: config,
          offers: [],
          diagnostics: { adapter: 'live-eapteka', city: context.city, query: '', error: 'empty query' },
        };
      }

      try {
        const offers = await fetchEaptekaProducts(query, context.city);
        return {
          source: config,
          offers: offers.map((o) => normalizeSourcePayload(o, config.id)),
          diagnostics: {
            adapter: 'live-eapteka',
            city: context.city,
            query,
            domain: 'eapteka.ru',
            fetchedCount: offers.length,
            live: true,
          },
        };
      } catch (err) {
        console.error('[live-eapteka] fetch error:', err.message);
        return {
          source: config,
          offers: [],
          diagnostics: {
            adapter: 'live-eapteka',
            city: context.city,
            query,
            error: err.message,
            live: false,
          },
        };
      }
    },
  };
}
