import { SOURCE_CATALOG } from './source-config.js'
import { createMockSourceAdapter } from './sources/mock-source-adapter.js'
import { createLiveEaptekaAdapter } from './sources/live-eapteka-adapter.js'

function buildAdapter(config) {
  if (config.id === 'eapteka') {
    return createLiveEaptekaAdapter(config)
  }
  return createMockSourceAdapter(config)
}

const REGISTRY = SOURCE_CATALOG.map((config) => buildAdapter(config))

export function getAllSourceAdapters() {
  return REGISTRY
}

export function getSourceAdaptersByIds(sourceIds = null) {
  if (sourceIds == null) {
    return REGISTRY
  }

  const selected = new Set(sourceIds)
  return REGISTRY.filter((source) => selected.has(source.id))
}
