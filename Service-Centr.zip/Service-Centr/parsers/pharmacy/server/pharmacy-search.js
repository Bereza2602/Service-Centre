import { getAvailableCitiesCount, getCityLabel } from './pharmacy-data.js'
import { getSourceAdaptersByIds } from './source-registry.js'
import {
  applySort,
  buildSourceSummary,
  dedupeOffers,
  formatPrice,
  matchQuery,
  normalizeQuery,
} from './lib/offer-utils.js'

export async function searchPharmacies({
  city = 'ekaterinburg',
  query = '',
  maxPrice = null,
  onlyInStock = false,
  sortBy = 'price-asc',
  sourceIds = [],
  limit = 100,
}) {
  const normalizedQuery = normalizeQuery(query)
  const requestedSources = getSourceAdaptersByIds(sourceIds)

  const sourceResults = await Promise.all(
    requestedSources.map((source) =>
      source.search({
        city,
        query,
      }),
    ),
  )

  const allOffers = sourceResults.flatMap((result) => result.offers)

  const filtered = allOffers.filter((offer) => {
    if (offer.city !== city) return false
    if (maxPrice !== null && offer.price > maxPrice) return false
    if (onlyInStock && offer.stockCount <= 0) return false
    return matchQuery(offer, normalizedQuery)
  })

  const offers = applySort(dedupeOffers(filtered), sortBy).slice(0, limit)
  const cheapest = offers[0] ?? null
  const averagePrice =
    offers.length > 0
      ? offers.reduce((sum, offer) => sum + offer.price, 0) / offers.length
      : 0

  return {
    source: 'parserapteka.local',
    filters: {
      city,
      cityLabel: getCityLabel(city),
      query,
      maxPrice,
      onlyInStock,
      sortBy,
      sourceIds: requestedSources.map((source) => source.id),
      limit,
      regionAware: true,
    },
    meta: {
      totalOffers: offers.length,
      cheapestPriceText: cheapest ? cheapest.priceText : 'Нет данных',
      averagePriceText: offers.length ? formatPrice(averagePrice) : 'Нет данных',
      citiesCovered: getAvailableCitiesCount(),
      sourcePriority: requestedSources,
      sourceSummary: buildSourceSummary(offers, requestedSources),
      regionalNote:
        'Цены и наличие считаются по выбранному городу, потому что у аптек данные отличаются между регионами.',
      requiredSourceFields: [
        'productName',
        'price',
        'stockLabel',
        'pharmacyName',
        'address',
        'phone',
        'city',
        'lat',
        'lon',
      ],
      parserMode:
        'Мульти-источник: поиск идёт по каталогу товаров, синонимам, действующим веществам, аптекам и источникам.',
    },
    heroOffer: cheapest,
    diagnostics: sourceResults.map((result) => result.diagnostics),
    offers,
  }
}
