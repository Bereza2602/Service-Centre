import http from 'node:http'
import { URL } from 'node:url'
import { searchPharmacies } from './pharmacy-search.js'
import { SOURCE_CATALOG, REQUIRED_SOURCE_FIELDS } from './source-config.js'
import { parseSourcesParam } from './lib/offer-utils.js'

const PORT = Number(process.env.PORT || 3001)

function sendJson(response, statusCode, payload) {
  response.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  })

  response.end(JSON.stringify(payload))
}

const server = http.createServer(async (request, response) => {
  if (!request.url) {
    sendJson(response, 400, { error: 'Empty request URL' })
    return
  }

  if (request.method === 'OPTIONS') {
    response.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    })
    response.end()
    return
  }

  const url = new URL(request.url, `http://${request.headers.host}`)

  if (request.method === 'GET' && url.pathname === '/api/health') {
    sendJson(response, 200, { ok: true, service: 'parserapteka' })
    return
  }

  if (request.method === 'GET' && url.pathname === '/api/sources') {
    sendJson(response, 200, {
      total: SOURCE_CATALOG.length,
      requiredFields: REQUIRED_SOURCE_FIELDS,
      sources: SOURCE_CATALOG,
    })
    return
  }

  if (request.method === 'GET' && url.pathname === '/api/search') {
    try {
      const city = url.searchParams.get('city') || 'ekaterinburg'
      const query = url.searchParams.get('query') || ''
      const maxPriceRaw = url.searchParams.get('maxPrice')
      const sortBy = url.searchParams.get('sortBy') || 'price-asc'
      const onlyInStock = url.searchParams.get('onlyInStock') === 'true'
      const rawSources = url.searchParams.get('sources')
      const sourceIds = rawSources === null ? null : parseSourcesParam(rawSources)
      const limitRaw = url.searchParams.get('limit')

      const result = await searchPharmacies({
        city,
        query,
        maxPrice: maxPriceRaw ? Number(maxPriceRaw) : null,
        sortBy,
        onlyInStock,
        sourceIds,
        limit: limitRaw ? Number(limitRaw) : 100,
      })

      sendJson(response, 200, result)
      return
    } catch (error) {
      sendJson(response, 500, {
        error: 'Failed to search pharmacy data',
        details: error instanceof Error ? error.message : 'Unknown error',
      })
      return
    }
  }

  sendJson(response, 404, { error: 'Not found' })
})

server.listen(PORT, () => {
  console.log(`ParserApteka API is running on http://localhost:${PORT}`)
})
