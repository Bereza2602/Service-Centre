const PHARMACY_NETWORK_WEBSITES = {
  'Вита': 'https://vitafarma.ru',
  'Живика': 'https://zhivika.ru',
  'Планета Здоровья': 'https://planetazdorovo.ru',
  'Аптека66': 'https://apteka66.ru',
  '36,6': 'https://366.ru',
  'Озерки': 'https://ozerki.ru',
  'Ригла': 'https://rigla.ru',
  'Мелодия здоровья': 'https://melodia-zdorovia.ru',
  'Алоэ': 'https://aloeapteka.ru',
  'Надежда': 'https://apteka-nadezhda.ru',
  'Имплозия': 'https://implozia.ru',
  'Здравсити': 'https://zdravcity.ru',
  'Фармленд': 'https://farmland.ru',
  'Витаминка': 'https://vitaminka-apteka.ru',
}

export function getPharmacyWebsite(network) {
  return PHARMACY_NETWORK_WEBSITES[network] || ''
}

export const PHARMACY_POINTS = {
  ekaterinburg: [
    {
      network: 'Живика',
      pharmacyName: 'Аптека Живика на Малышева',
      address: 'Екатеринбург, ул. Малышева, 21/1',
      phone: '+7 (343) 376-32-80',
      schedule: '08:00-22:00',
      lat: 56.8334,
      lon: 60.5917,
      distanceKm: 0.6,
    },
    {
      network: 'Планета Здоровья',
      pharmacyName: 'Планета Здоровья на Ленина',
      address: 'Екатеринбург, пр. Ленина, 24/8',
      phone: '+7 (343) 289-00-00',
      schedule: 'Круглосуточно',
      lat: 56.8367,
      lon: 60.5931,
      distanceKm: 0.7,
    },
    {
      network: 'Аптека66',
      pharmacyName: 'Аптека66 на Щорса',
      address: 'Екатеринбург, ул. Щорса, 70',
      phone: '+7 (343) 361-31-81',
      schedule: '08:00-22:00',
      lat: 56.8108,
      lon: 60.6122,
      distanceKm: 3.2,
    },
  ],
  moskva: [
    {
      network: '36,6',
      pharmacyName: 'Аптека 36,6 на Тверской',
      address: 'Москва, ул. Тверская, 18к1',
      phone: '+7 (495) 123-45-67',
      schedule: '08:00-23:00',
      lat: 55.7654,
      lon: 37.6046,
      distanceKm: 1.1,
    },
  ],
  'sankt-peterburg': [
    {
      network: 'Озерки',
      pharmacyName: 'Аптека Озерки на Невском',
      address: 'Санкт-Петербург, Невский пр., 184',
      phone: '+7 (812) 603-00-01',
      schedule: 'Пн-Пт 07:00-23:00, Сб-Вс 08:00-22:00',
      lat: 59.9217,
      lon: 30.3932,
      distanceKm: 0.8,
    },
  ],
  kazan: [
    {
      network: 'Ригла',
      pharmacyName: 'Ригла на Баумана',
      address: 'Казань, ул. Баумана, 62',
      phone: '+7 (843) 210-55-70',
      schedule: '09:00-22:00',
      lat: 55.7903,
      lon: 49.1127,
      distanceKm: 1.6,
    },
  ],
  novosibirsk: [
    {
      network: 'Мелодия здоровья',
      pharmacyName: 'Мелодия здоровья на Красном проспекте',
      address: 'Новосибирск, Красный проспект, 17',
      phone: '+7 (383) 255-10-10',
      schedule: '08:30-22:00',
      lat: 55.0302,
      lon: 82.9204,
      distanceKm: 2.1,
    },
  ],
  orenburg: [
    {
      network: 'Вита',
      pharmacyName: 'Аптека Вита на Советской',
      address: 'Оренбург, ул. Советская, 24',
      phone: '+7 (3532) 77-55-66',
      schedule: '08:00-22:00',
      lat: 51.7682,
      lon: 55.0970,
      distanceKm: 0.5,
    },
    {
      network: 'Вита',
      pharmacyName: 'Аптека Вита на Терешковой',
      address: 'Оренбург, ул. Терешковой, 140',
      phone: '+7 (3532) 33-44-55',
      schedule: 'Круглосуточно',
      lat: 51.7876,
      lon: 55.1205,
      distanceKm: 2.1,
    },
    {
      network: '36,6',
      pharmacyName: 'Аптека 36,6 на Победы',
      address: 'Оренбург, пр. Победы, 118',
      phone: '+7 (3532) 44-88-99',
      schedule: '09:00-22:00',
      lat: 51.7901,
      lon: 55.1412,
      distanceKm: 3.0,
    },
    {
      network: 'Планета Здоровья',
      pharmacyName: 'Планета Здоровья на Джангильдина',
      address: 'Оренбург, ул. Джангильдина, 7',
      phone: '+7 (3532) 55-11-22',
      schedule: '08:00-21:00',
      lat: 51.7734,
      lon: 55.0798,
      distanceKm: 1.2,
    },
    {
      network: 'Надежда',
      pharmacyName: 'Аптека Надежда на Чкалова',
      address: 'Оренбург, ул. Чкалова, 31',
      phone: '+7 (3532) 66-77-88',
      schedule: '08:00-20:00',
      lat: 51.7965,
      lon: 55.1089,
      distanceKm: 3.5,
    },
    {
      network: 'Имплозия',
      pharmacyName: 'Аптека Имплозия на Салмышской',
      address: 'Оренбург, ул. Салмышская, 29',
      phone: '+7 (3532) 99-00-11',
      schedule: '09:00-21:00',
      lat: 51.7823,
      lon: 55.1512,
      distanceKm: 4.0,
    },
  ],
  samara: [
    {
      network: 'Вита',
      pharmacyName: 'Аптека Вита на Московском',
      address: 'Самара, Московское шоссе, 18',
      phone: '+7 (846) 200-30-40',
      schedule: '08:00-22:00',
      lat: 53.2023,
      lon: 50.1527,
      distanceKm: 0.6,
    },
    {
      network: 'Фармленд',
      pharmacyName: 'Фармленд на Ленинградской',
      address: 'Самара, ул. Ленинградская, 40',
      phone: '+7 (846) 333-55-66',
      schedule: '09:00-21:00',
      lat: 53.1952,
      lon: 50.1461,
      distanceKm: 1.1,
    },
  ],
  ufa: [
    {
      network: 'Здравсити',
      pharmacyName: 'Здравсити на Октября',
      address: 'Уфа, пр. Октября, 71',
      phone: '+7 (347) 244-55-66',
      schedule: '08:00-22:00',
      lat: 54.7501,
      lon: 56.0102,
      distanceKm: 0.7,
    },
    {
      network: 'Ригла',
      pharmacyName: 'Ригла на Ленина',
      address: 'Уфа, ул. Ленина, 32',
      phone: '+7 (347) 277-88-99',
      schedule: 'Круглосуточно',
      lat: 54.7365,
      lon: 55.9598,
      distanceKm: 1.8,
    },
  ],
  chelyabinsk: [
    {
      network: 'Алоэ',
      pharmacyName: 'Алоэ на Кирова',
      address: 'Челябинск, ул. Кирова, 159',
      phone: '+7 (351) 266-77-88',
      schedule: '09:00-22:00',
      lat: 55.1599,
      lon: 61.4028,
      distanceKm: 0.9,
    },
    {
      network: 'Витаминка',
      pharmacyName: 'Витаминка на Ленина',
      address: 'Челябинск, пр. Ленина, 52',
      phone: '+7 (351) 222-33-44',
      schedule: '08:00-21:00',
      lat: 55.1644,
      lon: 61.3801,
      distanceKm: 1.5,
    },
  ],
  rostov: [
    {
      network: 'Озерки',
      pharmacyName: 'Озерки на Будённовском',
      address: 'Ростов-на-Дону, Будённовский пр., 55',
      phone: '+7 (863) 288-99-00',
      schedule: '08:00-23:00',
      lat: 47.2257,
      lon: 39.7201,
      distanceKm: 0.4,
    },
    {
      network: '36,6',
      pharmacyName: 'Аптека 36,6 на Большой Садовой',
      address: 'Ростов-на-Дону, ул. Большая Садовая, 88',
      phone: '+7 (863) 255-66-77',
      schedule: '09:00-22:00',
      lat: 47.2212,
      lon: 39.7189,
      distanceKm: 1.0,
    },
  ],
}

export const PRODUCT_CATALOG = [
  {
    key: 'nurofen',
    productName: 'Нурофен Экспресс 200 мг, 10 капсул',
    form: 'Капсулы',
    basePrice: 289,
    prescription: false,
    aliases: ['нурофен', 'ибупрофен', 'nurofen', 'ibuprofen', 'обезболивающее', 'температура'],
  },
  {
    key: 'paracetamol',
    productName: 'Парацетамол 500 мг, 20 таблеток',
    form: 'Таблетки',
    basePrice: 49,
    prescription: false,
    aliases: ['парацетамол', 'paracetamol', 'жаропонижающее', 'температура', 'простуда'],
  },
  {
    key: 'citramon',
    productName: 'Цитрамон П, 20 таблеток',
    form: 'Таблетки',
    basePrice: 75,
    prescription: false,
    aliases: ['цитрамон', 'citramon', 'голова', 'головная боль', 'кофеин'],
  },
  {
    key: 'aquadetrim',
    productName: 'Аквадетрим витамин D3, 15 мл',
    form: 'Капли',
    basePrice: 219,
    prescription: false,
    aliases: ['аквадетрим', 'витамин d', 'витамин д', 'd3', 'детям'],
  },
  {
    key: 'omega3',
    productName: 'Омега-3 1000 мг, 30 капсул',
    form: 'Капсулы',
    basePrice: 389,
    prescription: false,
    aliases: ['омега', 'омега 3', 'omega', 'omega 3', 'рыбий жир'],
  },
  {
    key: 'suprastin',
    productName: 'Супрастин 25 мг, 20 таблеток',
    form: 'Таблетки',
    basePrice: 164,
    prescription: false,
    aliases: ['супрастин', 'suprastin', 'аллергия', 'антигистамин'],
  },
  {
    key: 'loratadine',
    productName: 'Лоратадин 10 мг, 10 таблеток',
    form: 'Таблетки',
    basePrice: 63,
    prescription: false,
    aliases: ['лоратадин', 'loratadine', 'аллергия', 'насморк'],
  },
  {
    key: 'mezim',
    productName: 'Мезим форте, 20 таблеток',
    form: 'Таблетки',
    basePrice: 142,
    prescription: false,
    aliases: ['мезим', 'mezim', 'панкреатин', 'желудок', 'пищеварение'],
  },
  {
    key: 'smecta',
    productName: 'Смекта, порошок 10 пакетиков',
    form: 'Порошок',
    basePrice: 178,
    prescription: false,
    aliases: ['смекта', 'smecta', 'диарея', 'живот', 'отравление'],
  },
  {
    key: 'enterosgel',
    productName: 'Энтеросгель паста, 225 г',
    form: 'Паста',
    basePrice: 512,
    prescription: false,
    aliases: ['энтеросгель', 'enterosgel', 'сорбент', 'отравление', 'живот'],
  },
  {
    key: 'miramistin',
    productName: 'Мирамистин раствор 0,01%, 150 мл',
    form: 'Раствор',
    basePrice: 428,
    prescription: false,
    aliases: ['мирамистин', 'miramistin', 'горло', 'антисептик'],
  },
  {
    key: 'teraflu',
    productName: 'ТераФлю от гриппа и простуды, 10 пакетиков',
    form: 'Порошок',
    basePrice: 496,
    prescription: false,
    aliases: ['терафлю', 'teraflu', 'простуда', 'грипп', 'температура'],
  },
  {
    key: 'aspirin',
    productName: 'Аспирин 500 мг, 20 таблеток',
    form: 'Таблетки',
    basePrice: 118,
    prescription: false,
    aliases: ['аспирин', 'aspirin', 'ацетилсалициловая', 'голова', 'температура'],
  },
  {
    key: 'no-shpa',
    productName: 'Но-шпа 40 мг, 24 таблетки',
    form: 'Таблетки',
    basePrice: 224,
    prescription: false,
    aliases: ['но-шпа', 'ношпа', 'no-shpa', 'дротаверин', 'спазм', 'живот'],
  },
  {
    key: 'activated-charcoal',
    productName: 'Уголь активированный, 50 таблеток',
    form: 'Таблетки',
    basePrice: 72,
    prescription: false,
    aliases: ['уголь', 'активированный уголь', 'сорбент', 'отравление', 'живот'],
  },
  {
    key: 'chlorhexidine',
    productName: 'Хлоргексидин раствор 0,05%, 100 мл',
    form: 'Раствор',
    basePrice: 36,
    prescription: false,
    aliases: ['хлоргексидин', 'chlorhexidine', 'антисептик', 'рана', 'обработка'],
  },
  {
    key: 'rinza',
    productName: 'Ринза, 10 таблеток',
    form: 'Таблетки',
    basePrice: 188,
    prescription: false,
    aliases: ['ринза', 'rinza', 'простуда', 'грипп', 'насморк', 'температура'],
  },
  {
    key: 'amoxicillin',
    productName: 'Амоксициллин 500 мг, 16 капсул',
    form: 'Капсулы',
    basePrice: 198,
    prescription: true,
    aliases: ['амоксициллин', 'amoxicillin', 'антибиотик', 'инфекция'],
  },
  {
    key: 'ketorol',
    productName: 'Кеторол 10 мг, 20 таблеток',
    form: 'Таблетки',
    basePrice: 147,
    prescription: true,
    aliases: ['кеторол', 'ketorol', 'кеторолак', 'обезболивающее', 'сильная боль'],
  },
  {
    key: 'trental',
    productName: 'Трентал 100 мг, 60 таблеток',
    form: 'Таблетки',
    basePrice: 856,
    prescription: true,
    aliases: ['трентал', 'trental', 'пентоксифиллин', 'сосуды'],
  },
]

function getSourceProductUrl(sourceId, productName) {
  const q = encodeURIComponent(productName)
  const urls = {
    uteka: `https://uteka.ru/search/?q=${q}`,
    'apteka-ru': `https://apteka.ru/search/?q=${q}`,
    eapteka: `https://eapteka.ru/search/?q=${q}`,
    zdravcity: `https://zdravcity.ru/search/?q=${q}`,
    vita: `https://vitafarma.ru/search/?q=${q}`,
    ozerki: `https://ozerki.ru/search/?q=${q}`,
    rigla: `https://rigla.ru/search/?q=${q}`,
    planetazdorovo: `https://planetazdorovo.ru/search/?q=${q}`,
    farmland: `https://farmland.ru/search/?q=${q}`,
    aloe: `https://aloeapteka.ru/search/?q=${q}`,
    nadezhda: `https://apteka-nadezhda.ru/search/?q=${q}`,
    implozia: `https://implozia.ru/search/?q=${q}`,
    vitaminka: `https://vitaminka-apteka.ru/search/?q=${q}`,
    'melodia-zdorovia': `https://melodia-zdorovia.ru/search/?q=${q}`,
    zhivika: `https://zhivika.ru/search/?q=${q}`,
    apteka66: `https://apteka66.ru/search/?q=${q}`,
  }
  return urls[sourceId] || `https://example.com/search?q=${q}`
}

const SOURCE_PRICE_MULTIPLIER = {
  uteka: 0.97,
  'apteka-ru': 1.02,
  eapteka: 1.08,
  zdravcity: 1,
  vita: 0.99,
  ozerki: 0.96,
  rigla: 1.03,
  planetazdorovo: 1,
  farmland: 0.95,
  aloe: 1.01,
  nadezhda: 0.93,
  implozia: 0.98,
  vitaminka: 0.97,
  'melodia-zdorovia': 1.04,
  zhivika: 0.98,
  apteka66: 0.94,
}

const CITY_PRICE_MULTIPLIER = {
  ekaterinburg: 1,
  moskva: 1.12,
  'sankt-peterburg': 1.07,
  kazan: 0.98,
  novosibirsk: 1.01,
  orenburg: 0.95,
  samara: 0.97,
  ufa: 0.96,
  chelyabinsk: 0.98,
  rostov: 0.99,
}

function makeStableNumber(value) {
  return Array.from(value).reduce((sum, char) => sum + char.charCodeAt(0), 0)
}

export function buildCatalogOffersForSource(sourceId) {
  const sourceMultiplier = SOURCE_PRICE_MULTIPLIER[sourceId] ?? 1
  const offers = []

  for (const [city, pharmacies] of Object.entries(PHARMACY_POINTS)) {
    const cityMultiplier = CITY_PRICE_MULTIPLIER[city] ?? 1

    for (const [pharmacyIndex, pharmacy] of pharmacies.entries()) {
      for (const product of PRODUCT_CATALOG) {
        const seed = makeStableNumber(`${sourceId}-${city}-${pharmacyIndex}-${product.key}`)
        const price = Math.max(
          29,
          Math.round(product.basePrice * sourceMultiplier * cityMultiplier + (seed % 23) - 11),
        )
        const stockCount = seed % 7 === 0 ? 0 : seed % 11 === 0 ? 1 : (seed % 19) + 1
        let stockLabel
        if (stockCount === 0) stockLabel = 'Нет в наличии'
        else if (stockCount === 1 && seed % 3 === 0) stockLabel = 'Выставочный экземпляр'
        else if (stockCount <= 3) stockLabel = 'Заканчивается'
        else stockLabel = 'В наличии'

        const website = getPharmacyWebsite(pharmacy.network)
        offers.push({
          ...pharmacy,
          website,
          id: `${sourceId}-${city}-${pharmacyIndex}-${product.key}`,
          city,
          productKey: product.key,
          productName: product.productName,
          form: product.form,
          aliases: product.aliases,
          prescription: product.prescription,
          price,
          oldPrice: Math.round(price * 1.14),
          stockCount,
          stockLabel,
          isOpenNow: pharmacy.schedule === 'Круглосуточно' || stockCount % 2 === 0,
          description: `Предложение по товару "${product.productName}" в аптеке ${pharmacy.pharmacyName}. Цена, наличие, адрес и телефон.`,
          reserveUrl: getSourceProductUrl(sourceId, product.productName),
        })
      }
    }
  }

  return offers
}
