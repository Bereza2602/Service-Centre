const CITY_LABELS = {
  moskva: 'Москва',
  'sankt-peterburg': 'Санкт-Петербург',
  ekaterinburg: 'Екатеринбург',
  kazan: 'Казань',
  novosibirsk: 'Новосибирск',
  orenburg: 'Оренбург',
  samara: 'Самара',
  ufa: 'Уфа',
  chelyabinsk: 'Челябинск',
  rostov: 'Ростов-на-Дону',
}

import { getSourceConfig, normalizeSourcePayload, SOURCE_CATALOG } from './source-config.js'

const RAW_OFFERS = [
  {
    id: 'ekb-1',
    city: 'ekaterinburg',
    network: 'Живика',
    pharmacyName: 'Аптека Живика на Малышева',
    productName: 'Нурофен Экспресс 200 мг, 10 капсул',
    form: 'Капсулы',
    price: 289,
    oldPrice: 337,
    stockCount: 18,
    stockLabel: 'В наличии',
    distanceKm: 0.8,
    phone: '+7 (343) 287-10-20',
    schedule: '08:00-22:00',
    isOpenNow: true,
    address: 'Екатеринбург, ул. Малышева, 51',
    lat: 56.8389,
    lon: 60.6057,
    description:
      'Быстрая выдача, можно забронировать через сайт и забрать рядом с метро Площадь 1905 года.',
    reserveUrl: 'https://example.com/reserve/ekb-1',
    sourceId: 'uteka',
  },
  {
    id: 'ekb-2',
    city: 'ekaterinburg',
    network: 'Планета Здоровья',
    pharmacyName: 'Планета Здоровья на Ленина',
    productName: 'Нурофен Экспресс 200 мг, 10 капсул',
    form: 'Капсулы',
    price: 301,
    oldPrice: 349,
    stockCount: 7,
    stockLabel: 'Заканчивается',
    distanceKm: 1.4,
    phone: '+7 (343) 226-02-20',
    schedule: 'Круглосуточно',
    isOpenNow: true,
    address: 'Екатеринбург, пр. Ленина, 40',
    lat: 56.8386,
    lon: 60.6167,
    description:
      'Аптека с ночной выдачей. Удобно, если препарат нужен срочно и без ожидания утра.',
    reserveUrl: 'https://example.com/reserve/ekb-2',
    sourceId: 'zdravcity',
  },
  {
    id: 'ekb-3',
    city: 'ekaterinburg',
    network: 'Аптека66',
    pharmacyName: 'Аптека66 на Щорса',
    productName: 'Аквадетрим витамин D3, 15 мл',
    form: 'Капли',
    price: 219,
    oldPrice: 260,
    stockCount: 14,
    stockLabel: 'В наличии',
    distanceKm: 3.2,
    phone: '+7 (343) 300-44-66',
    schedule: '09:00-21:00',
    isOpenNow: true,
    address: 'Екатеринбург, ул. Щорса, 54',
    lat: 56.8108,
    lon: 60.6122,
    description:
      'Популярная точка по детским товарам и витаминам, часто даёт цену ниже среднего по району.',
    reserveUrl: 'https://example.com/reserve/ekb-3',
    sourceId: 'apteka-ru',
  },
  {
    id: 'msk-1',
    city: 'moskva',
    network: '36,6',
    pharmacyName: 'Аптека 36,6 на Тверской',
    productName: 'Нурофен Экспресс 200 мг, 10 капсул',
    form: 'Капсулы',
    price: 319,
    oldPrice: 379,
    stockCount: 11,
    stockLabel: 'В наличии',
    distanceKm: 1.1,
    phone: '+7 (495) 123-45-67',
    schedule: '08:00-23:00',
    isOpenNow: true,
    address: 'Москва, ул. Тверская, 18к1',
    lat: 55.7654,
    lon: 37.6046,
    description:
      'Удобная аптека в центре с онлайн-бронированием и быстрой выдачей заказа.',
    reserveUrl: 'https://example.com/reserve/msk-1',
    sourceId: 'eapteka',
  },
  {
    id: 'spb-1',
    city: 'sankt-peterburg',
    network: 'Озерки',
    pharmacyName: 'Аптека Озерки на Невском',
    productName: 'Нурофен Экспресс 200 мг, 10 капсул',
    form: 'Капсулы',
    price: 295,
    oldPrice: 340,
    stockCount: 22,
    stockLabel: 'В наличии',
    distanceKm: 0.9,
    phone: '+7 (812) 600-11-22',
    schedule: 'Круглосуточно',
    isOpenNow: true,
    address: 'Санкт-Петербург, Невский пр., 114',
    lat: 59.9311,
    lon: 30.3609,
    description:
      'Сильная точка по популярным обезболивающим и товарам для домашней аптечки.',
    reserveUrl: 'https://example.com/reserve/spb-1',
    sourceId: 'uteka',
  },
  {
    id: 'kzn-1',
    city: 'kazan',
    network: 'Ригла',
    pharmacyName: 'Ригла на Баумана',
    productName: 'Нурофен Экспресс 200 мг, 10 капсул',
    form: 'Капсулы',
    price: 287,
    oldPrice: 328,
    stockCount: 9,
    stockLabel: 'В наличии',
    distanceKm: 1.6,
    phone: '+7 (843) 210-55-70',
    schedule: '09:00-22:00',
    isOpenNow: true,
    address: 'Казань, ул. Баумана, 62',
    lat: 55.7903,
    lon: 49.1127,
    description:
      'Хорошая цена на популярные обезболивающие, можно забрать заказ день в день.',
    reserveUrl: 'https://example.com/reserve/kzn-1',
    sourceId: 'apteka-ru',
  },
  {
    id: 'nsk-1',
    city: 'novosibirsk',
    network: 'Мелодия здоровья',
    pharmacyName: 'Мелодия здоровья на Красном проспекте',
    productName: 'Нурофен Экспресс 200 мг, 10 капсул',
    form: 'Капсулы',
    price: 309,
    oldPrice: 358,
    stockCount: 13,
    stockLabel: 'В наличии',
    distanceKm: 2.1,
    phone: '+7 (383) 255-10-10',
    schedule: '08:30-22:00',
    isOpenNow: true,
    address: 'Новосибирск, Красный проспект, 17',
    lat: 55.0302,
    lon: 82.9204,
    description:
      'Надёжная городская точка с хорошим наличием препаратов от боли и простуды.',
    reserveUrl: 'https://example.com/reserve/nsk-1',
    sourceId: 'zdravcity',
  },
]

function makeMapUrl(lat, lon, label) {
  const encodedLabel = encodeURIComponent(label)
  return `https://yandex.ru/maps/?pt=${lon},${lat}&z=16&l=map&text=${encodedLabel}`
}

function makeGoogleMapsUrl(lat, lon) {
  return `https://www.google.com/maps/search/?api=1&query=${lat},${lon}`
}

function normalizePhone(phone) {
  return phone.replace(/[^\d+]/g, '')
}

export function getCityLabel(city) {
  return CITY_LABELS[city] ?? city
}

export function getAvailableCitiesCount() {
  return Object.keys(CITY_LABELS).length
}

export function getPharmacyOffers() {
  return RAW_OFFERS.map((offer) => normalizeSourcePayload({
    ...offer,
    cityLabel: getCityLabel(offer.city),
    priceText: `${offer.price.toLocaleString('ru-RU')} ₽`,
    oldPriceText: `${offer.oldPrice.toLocaleString('ru-RU')} ₽`,
    pricePerUnit: `${Math.round(offer.price / 10)} ₽ за капсулу`,
    distanceText: `${offer.distanceKm.toFixed(1).replace('.', ',')} км`,
    phoneRaw: normalizePhone(offer.phone),
    mapUrl: makeMapUrl(
      offer.lat,
      offer.lon,
      `${offer.pharmacyName}, ${offer.address}`,
    ),
    googleMapsUrl: makeGoogleMapsUrl(offer.lat, offer.lon),
  }, offer.sourceId))
}

export function getSourcePriority() {
  return SOURCE_CATALOG.filter((source) => source.enabled).map((source) => ({
    id: source.id,
    name: source.name,
    priority: source.priority,
    mode: source.mode,
    regionAware: source.regionAware,
    strengths: source.strengths,
    domains: source.domains,
    readyForDomainBinding: source.readyForDomainBinding,
  }))
}
