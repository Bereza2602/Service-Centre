export const REQUIRED_SOURCE_FIELDS = [
  'productName',
  'price',
  'stockLabel',
  'pharmacyName',
  'address',
  'phone',
  'city',
  'lat',
  'lon',
  'website',
  'prescription',
]

export const SOURCE_CATALOG = [
  {
    id: 'uteka',
    name: 'Ютека',
    priority: 1,
    domains: ['uteka.ru'],
    mode: 'compare',
    regionAware: true,
    enabled: true,
    readyForDomainBinding: true,
    strengths: ['цены', 'сравнение аптек', 'наличие'],
    requiredFields: REQUIRED_SOURCE_FIELDS,
  },
  {
    id: 'apteka-ru',
    name: 'Apteka.ru',
    priority: 2,
    domains: ['apteka.ru'],
    mode: 'catalog',
    regionAware: true,
    enabled: true,
    readyForDomainBinding: true,
    strengths: ['каталог', 'карточки товаров', 'цены'],
    requiredFields: REQUIRED_SOURCE_FIELDS,
  },
  {
    id: 'eapteka',
    name: 'ЕАПТЕКА',
    priority: 3,
    domains: ['eapteka.ru'],
    mode: 'catalog',
    regionAware: true,
    enabled: true,
    readyForDomainBinding: true,
    strengths: ['ассортимент', 'карточки товаров'],
    requiredFields: REQUIRED_SOURCE_FIELDS,
  },
  {
    id: 'zdravcity',
    name: 'Здравсити',
    priority: 4,
    domains: ['zdravcity.ru'],
    mode: 'availability',
    regionAware: true,
    enabled: true,
    readyForDomainBinding: true,
    strengths: ['наличие', 'цены', 'резервная проверка'],
    requiredFields: REQUIRED_SOURCE_FIELDS,
  },
  {
    id: 'vita',
    name: 'Вита',
    priority: 5,
    domains: ['vitafarma.ru'],
    mode: 'catalog',
    regionAware: true,
    enabled: true,
    readyForDomainBinding: true,
    strengths: ['цены', 'наличие', 'сеть аптек'],
    requiredFields: REQUIRED_SOURCE_FIELDS,
  },
  {
    id: 'ozerki',
    name: 'Озерки',
    priority: 6,
    domains: ['ozerki.ru'],
    mode: 'catalog',
    regionAware: true,
    enabled: true,
    readyForDomainBinding: true,
    strengths: ['доступные цены', 'широкий ассортимент'],
    requiredFields: REQUIRED_SOURCE_FIELDS,
  },
  {
    id: 'rigla',
    name: 'Ригла',
    priority: 7,
    domains: ['rigla.ru'],
    mode: 'catalog',
    regionAware: true,
    enabled: true,
    readyForDomainBinding: true,
    strengths: ['федеральная сеть', 'бонусная программа'],
    requiredFields: REQUIRED_SOURCE_FIELDS,
  },
  {
    id: 'planetazdorovo',
    name: 'Планета Здоровья',
    priority: 8,
    domains: ['planetazdorovo.ru'],
    mode: 'catalog',
    regionAware: true,
    enabled: true,
    readyForDomainBinding: true,
    strengths: ['круглосуточные аптеки', 'наличие'],
    requiredFields: REQUIRED_SOURCE_FIELDS,
  },
  {
    id: 'farmland',
    name: 'Фармленд',
    priority: 9,
    domains: ['farmland.ru'],
    mode: 'catalog',
    regionAware: true,
    enabled: true,
    readyForDomainBinding: true,
    strengths: ['цены', 'скидки', 'акции'],
    requiredFields: REQUIRED_SOURCE_FIELDS,
  },
  {
    id: 'aloe',
    name: 'Алоэ',
    priority: 10,
    domains: ['aloeapteka.ru'],
    mode: 'catalog',
    regionAware: true,
    enabled: true,
    readyForDomainBinding: true,
    strengths: ['натуральные препараты', 'цены'],
    requiredFields: REQUIRED_SOURCE_FIELDS,
  },
  {
    id: 'nadezhda',
    name: 'Надежда',
    priority: 11,
    domains: ['apteka-nadezhda.ru'],
    mode: 'catalog',
    regionAware: true,
    enabled: true,
    readyForDomainBinding: true,
    strengths: ['социальные цены', 'наличие'],
    requiredFields: REQUIRED_SOURCE_FIELDS,
  },
  {
    id: 'implozia',
    name: 'Имплозия',
    priority: 12,
    domains: ['implozia.ru'],
    mode: 'availability',
    regionAware: true,
    enabled: true,
    readyForDomainBinding: true,
    strengths: ['наличие', 'резерв'],
    requiredFields: REQUIRED_SOURCE_FIELDS,
  },
  {
    id: 'vitaminka',
    name: 'Витаминка',
    priority: 13,
    domains: ['vitaminka-apteka.ru'],
    mode: 'catalog',
    regionAware: true,
    enabled: true,
    readyForDomainBinding: true,
    strengths: ['витамины', 'БАДы', 'цены'],
    requiredFields: REQUIRED_SOURCE_FIELDS,
  },
  {
    id: 'melodia-zdorovia',
    name: 'Мелодия здоровья',
    priority: 14,
    domains: ['melodia-zdorovia.ru'],
    mode: 'catalog',
    regionAware: true,
    enabled: true,
    readyForDomainBinding: true,
    strengths: ['ассортимент', 'наличие'],
    requiredFields: REQUIRED_SOURCE_FIELDS,
  },
  {
    id: 'zhivika',
    name: 'Живика',
    priority: 15,
    domains: ['zhivika.ru'],
    mode: 'catalog',
    regionAware: true,
    enabled: true,
    readyForDomainBinding: true,
    strengths: ['цены', 'бронирование'],
    requiredFields: REQUIRED_SOURCE_FIELDS,
  },
  {
    id: 'apteka66',
    name: 'Аптека66',
    priority: 16,
    domains: ['apteka66.ru'],
    mode: 'catalog',
    regionAware: true,
    enabled: true,
    readyForDomainBinding: true,
    strengths: ['местная сеть', 'цены'],
    requiredFields: REQUIRED_SOURCE_FIELDS,
  },
]

export function getSourceConfig(sourceId) {
  return SOURCE_CATALOG.find((source) => source.id === sourceId) ?? null
}

function makeMapUrl(lat, lon, label) {
  const latStr = Number(lat).toFixed(6)
  const lonStr = Number(lon).toFixed(6)
  const encodedLabel = encodeURIComponent(label)
  return `https://yandex.ru/maps/?ll=${lonStr}%2C${latStr}&z=17&pt=${lonStr},${latStr},pm2rdm&text=${encodedLabel}`
}

function makeGoogleMapsUrl(lat, lon) {
  const latStr = Number(lat).toFixed(6)
  const lonStr = Number(lon).toFixed(6)
  return `https://www.google.com/maps/search/?api=1&query=${latStr},${lonStr}`
}

function normalizePhone(phone = '') {
  return phone.replace(/[^\d+]/g, '')
}

export function normalizeSourcePayload(rawOffer, sourceId) {
  const source = getSourceConfig(sourceId)

  return {
    ...rawOffer,
    priceText:
      rawOffer.price !== undefined
        ? `${rawOffer.price.toLocaleString('ru-RU')} ₽`
        : 'Цена не указана',
    oldPriceText:
      rawOffer.oldPrice !== undefined
        ? `${rawOffer.oldPrice.toLocaleString('ru-RU')} ₽`
        : '',
    pricePerUnit:
      rawOffer.price !== undefined ? `${Math.round(rawOffer.price / 10)} ₽ за единицу` : '',
    prescriptionText: rawOffer.prescription === true ? 'По рецепту' : 'Без рецепта',
    distanceText:
      rawOffer.distanceKm !== undefined
        ? `${rawOffer.distanceKm.toFixed(1).replace('.', ',')} км`
        : '',
    phoneRaw: normalizePhone(rawOffer.phone),
    mapUrl:
      rawOffer.lat !== undefined && rawOffer.lon !== undefined
        ? makeMapUrl(rawOffer.lat, rawOffer.lon, `${rawOffer.pharmacyName}, ${rawOffer.address}`)
        : '',
    googleMapsUrl:
      rawOffer.lat !== undefined && rawOffer.lon !== undefined
        ? makeGoogleMapsUrl(rawOffer.lat, rawOffer.lon)
        : '',
    source,
    missingFields: REQUIRED_SOURCE_FIELDS.filter(
      (field) => rawOffer[field] === undefined || rawOffer[field] === null || rawOffer[field] === '',
    ),
  }
}
