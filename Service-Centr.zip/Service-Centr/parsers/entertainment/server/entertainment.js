const NOMINATIM_URL = 'https://nominatim.openstreetmap.org/search'
const OVERPASS_URLS = [
  'https://overpass-api.de/api/interpreter',
  'https://overpass.kumi.systems/api/interpreter',
  'https://overpass.openstreetmap.ie/api/interpreter',
  'https://overpass.michel4a.com/api/interpreter',
]
const DEFAULT_LIMIT = 24
const GEOCODE_CACHE = new Map()

const CATEGORY_DEFINITIONS = {
  bowling: {
    label: 'Боулинг',
    queries: [['leisure', 'bowling']],
  },
  billiards: {
    label: 'Бильярд',
    queries: [['sport', 'billiards']],
  },
  computer_club: {
    label: 'ПК-клуб',
    queries: [
      ['leisure', 'adult_gaming_centre'],
      ['amenity', 'internet_cafe'],
      ['club', 'computer'],
    ],
  },
  pinball: {
    label: 'Пинбол',
    queries: [['attraction', 'pinball']],
  },
  karaoke: {
    label: 'Караоке',
    queries: [['amenity', 'karaoke_box']],
  },
  board_games: {
    label: 'Настолки / антикафе',
    queries: [
      ['amenity', 'social_centre'],
      ['amenity', 'community_centre'],
      ['amenity', 'cafe', 'board_game'],
    ],
  },
  arcade: {
    label: 'Игровой центр',
    queries: [
      ['leisure', 'amusement_arcade'],
      ['tourism', 'theme_park'],
    ],
  },
  cinema: {
    label: 'Кинотеатр',
    queries: [['amenity', 'cinema']],
  },
  quest: {
    label: 'Квесты',
    queries: [['leisure', 'escape_game']],
  },
  nightclub: {
    label: 'Ночной клуб',
    queries: [['amenity', 'nightclub']],
  },
  bar: {
    label: 'Бар / паб',
    queries: [
      ['amenity', 'bar'],
      ['amenity', 'pub'],
    ],
  },
  hookah: {
    label: 'Кальянная',
    queries: [['amenity', 'hookah_lounge']],
  },
  skating: {
    label: 'Каток / роллердром',
    queries: [
      ['leisure', 'ice_rink'],
      ['leisure', 'pitch', 'rollers'],
    ],
  },
  trampoline: {
    label: 'Батутный центр',
    queries: [['leisure', 'trampoline_park']],
  },
  waterpark: {
    label: 'Аквапарк / бассейн',
    queries: [
      ['leisure', 'water_park'],
      ['leisure', 'swimming_pool'],
    ],
  },
}

const CATEGORY_KEYWORDS = {
  bowling: /(боулинг|bowling)/i,
  billiards: /(бильярд|billiard|pool club|snooker)/i,
  computer_club: /(компьютер|pc club|cyber|esports|internet cafe|игровой клуб)/i,
  pinball: /(пинбол|pinball)/i,
  karaoke: /(караоке|karaoke)/i,
  board_games: /(настол|board game|антикафе|игротек)/i,
  arcade: /(аркад|arcade|game center|amusement)/i,
  cinema: /(кино|cinema|movie)/i,
  quest: /(квест|escape)/i,
  nightclub: /(nightclub|ночной клуб)/i,
  bar: /(бар|pub|taproom|beer)/i,
  hookah: /(кальян|hookah|shisha)/i,
  skating: /(каток|ice rink|роллер|roller)/i,
  trampoline: /(батут|trampoline)/i,
  waterpark: /(аквапарк|water park|бассейн|pool)/i,
}

function escapeOverpassValue(value) {
  return String(value).replace(/\\/g, '\\\\').replace(/"/g, '\\"')
}

function formatAddress(tags) {
  const parts = [
    tags['addr:postcode'],
    tags['addr:city'],
    tags['addr:street'],
    tags['addr:housenumber'],
  ].filter(Boolean)

  if (parts.length) {
    return parts.join(', ')
  }

  return (
    tags['addr:full'] ||
    tags.address ||
    tags['contact:address'] ||
    tags.description ||
    ''
  )
}

function pickPhone(tags) {
  return (
    tags['contact:phone'] ||
    tags.phone ||
    tags['contact:mobile'] ||
    tags.mobile ||
    ''
  )
}

function normalizeWebsiteCandidate(raw) {
  if (!raw) {
    return ''
  }

  const cleaned = String(raw).trim()

  if (!cleaned) {
    return ''
  }

  return /^https?:\/\//i.test(cleaned) ? cleaned : `https://${cleaned}`
}

function isOfficialWebsite(urlString) {
  try {
    const url = new URL(urlString)
    const hostname = url.hostname.toLowerCase().replace(/^www\./, '')
    const pathname = url.pathname.toLowerCase()
    const search = url.search.toLowerCase()

    const blockedHosts = [
      '2gis.ru',
      'go.2gis.com',
      'yandex.ru',
      'yandex.com',
      'maps.yandex.ru',
      'yandex.by',
      'google.com',
      'google.ru',
      'google.by',
      'google.kz',
      'maps.google.com',
      'openstreetmap.org',
    ]

    if (blockedHosts.some((host) => hostname === host || hostname.endsWith(`.${host}`))) {
      return false
    }

    if (
      pathname.includes('/maps') ||
      pathname.includes('/map') ||
      search.includes('ll=') ||
      search.includes('pt=') ||
      search.includes('q=') ||
      search.includes('query=')
    ) {
      return false
    }

    return true
  } catch {
    return false
  }
}

function pickWebsite(tags) {
  const candidates = [
    tags['contact:website'],
    tags.website,
    tags['brand:website'],
    tags['contact:url'],
    tags.url,
  ]

  for (const candidate of candidates) {
    const normalized = normalizeWebsiteCandidate(candidate)

    if (normalized && isOfficialWebsite(normalized)) {
      return normalized
    }
  }

  return ''
}

function parseBoundingBox(element) {
  if (element.bounds) {
    return {
      south: element.bounds.minlat,
      west: element.bounds.minlon,
      north: element.bounds.maxlat,
      east: element.bounds.maxlon,
    }
  }

  if (element.lat && element.lon) {
    return {
      south: element.lat,
      west: element.lon,
      north: element.lat,
      east: element.lon,
    }
  }

  return null
}

function toNumber(value) {
  const numeric = Number(value)
  return Number.isFinite(numeric) ? numeric : null
}

function haversineKm(fromLat, fromLon, toLat, toLon) {
  const radius = 6371
  const dLat = ((toLat - fromLat) * Math.PI) / 180
  const dLon = ((toLon - fromLon) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((fromLat * Math.PI) / 180) *
      Math.cos((toLat * Math.PI) / 180) *
      Math.sin(dLon / 2) ** 2

  return 2 * radius * Math.asin(Math.sqrt(a))
}

function buildMapLinks(lat, lon) {
  const latStr = lat.toFixed(6)
  const lonStr = lon.toFixed(6)

  return {
    openstreetmap: `https://www.openstreetmap.org/?mlat=${latStr}&mlon=${lonStr}#map=18/${latStr}/${lonStr}`,
    yandex: `https://yandex.ru/maps/?ll=${lonStr}%2C${latStr}&z=17&pt=${lonStr},${latStr},pm2rdm`,
    google: `https://www.google.com/maps/search/?api=1&query=${latStr},${lonStr}`,
  }
}

function buildOsmFeatureLink(type, id) {
  const osmType = ['node', 'way', 'relation'].includes(type) ? type : 'node'
  return `https://www.openstreetmap.org/${osmType}/${id}`
}

function getSearchableText(tags) {
  return [
    tags.name,
    tags.brand,
    tags.description,
    tags['short_description'],
    tags.operator,
    tags['club:type'],
    tags['community_centre:for'],
  ]
    .filter(Boolean)
    .join(' ')
    .toLowerCase()
}

function inferCategory(tags) {
  const searchableText = getSearchableText(tags)

  for (const [code, definition] of Object.entries(CATEGORY_DEFINITIONS)) {
    for (const query of definition.queries) {
      const [key, value, extra] = query

      if (extra === 'board_game') {
        if (tags[key] === value && CATEGORY_KEYWORDS.board_games.test(searchableText)) {
          return { code, label: definition.label }
        }

        continue
      }

      if (extra === 'rollers') {
        if (tags[key] === value && CATEGORY_KEYWORDS.skating.test(searchableText)) {
          return { code, label: definition.label }
        }

        continue
      }

      if (tags[key] === value) {
        return { code, label: definition.label }
      }
    }
  }

  for (const [code, pattern] of Object.entries(CATEGORY_KEYWORDS)) {
    if (pattern.test(searchableText)) {
      return {
        code,
        label: CATEGORY_DEFINITIONS[code]?.label || 'Развлечения',
      }
    }
  }

  return { code: 'other', label: 'Развлечения' }
}

const ALL_CATEGORY_SUBSET = [
  'bowling', 'computer_club', 'cinema', 'quest', 'nightclub',
  'bar', 'waterpark',
]

function buildOverpassQuery({ bbox, categories }) {
  const selected = categories.length
    ? categories.filter(
        (category) => category === 'all' || CATEGORY_DEFINITIONS[category],
      )
    : ['all']
  const categoryPool = selected.includes('all')
    ? ALL_CATEGORY_SUBSET
    : selected

  const filters = categoryPool.flatMap(
    (category) => CATEGORY_DEFINITIONS[category]?.queries ?? [],
  )

  const [south, north, west, east] = bbox
  const area = `(${south},${west},${north},${east})`
  const lines = filters.map(([key, value, extra]) => {
    if (extra === 'board_game') {
      return `nwr["${escapeOverpassValue(key)}"="${escapeOverpassValue(
        value,
      )}"]["name"~"настол|board|антикаф|игр", i]${area};`
    }

    return `nwr["${escapeOverpassValue(key)}"="${escapeOverpassValue(
      value,
    )}"]${area};`
  })

  return `[out:json][timeout:25];
(
${lines.join('\n')}
);
out center tags bb;`
}

async function fetchJson(url, options = {}, timeoutMs = 35000) {
  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), timeoutMs)

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal,
      headers: {
        'user-agent': 'ParserDosug/1.0 (local development project)',
        'accept-language': 'ru',
        ...(options.headers || {}),
      },
    })

    if (!response.ok) {
      const body = await response.text().catch(() => '')
      throw new Error(`Remote source returned ${response.status}: ${body.slice(0, 100)}`)
    }

    const contentType = response.headers.get('content-type') || ''
    if (!contentType.includes('json')) {
      const body = await response.text().catch(() => '')
      throw new Error(`Expected JSON, got ${contentType}: ${body.slice(0, 100)}`)
    }

    return response.json()
  } finally {
    clearTimeout(timer)
  }
}

async function fetchOverpassJson(body) {
  let lastError = null

  for (const endpoint of OVERPASS_URLS) {
    try {
      return await fetchJson(endpoint, {
        method: 'POST',
        headers: {
          'content-type': 'text/plain; charset=utf-8',
        },
        body,
      })
    } catch (error) {
      lastError = error
    }
  }

  throw lastError || new Error('Overpass is temporarily unavailable')
}

async function geocodeCity(city) {
  const key = city.trim().toLowerCase()
  const cached = GEOCODE_CACHE.get(key)
  if (cached) return cached

  const url = new URL(NOMINATIM_URL)
  url.searchParams.set('q', city)
  url.searchParams.set('format', 'jsonv2')
  url.searchParams.set('limit', '1')
  url.searchParams.set('addressdetails', '1')

  const data = await fetchJson(url)
  const first = Array.isArray(data) ? data[0] : null

  if (!first) {
    throw new Error(`City not found: ${city}`)
  }

  const result = {
    displayName: first.display_name || city,
    lat: toNumber(first.lat),
    lon: toNumber(first.lon),
    boundingbox: Array.isArray(first.boundingbox)
      ? first.boundingbox.map((value) => Number(value))
      : null,
  }

  GEOCODE_CACHE.set(key, result)
  return result
}

function normalizeVenue(element, cityMeta) {
  const tags = element.tags || {}
  const lat = toNumber(element.center?.lat ?? element.lat)
  const lon = toNumber(element.center?.lon ?? element.lon)

  if (lat === null || lon === null) {
    return null
  }

  const address = formatAddress(tags)
  const bbox = parseBoundingBox(element)
  const category = inferCategory(tags)
  const phone = pickPhone(tags)
  const website = pickWebsite(tags)
  const distanceKm = haversineKm(cityMeta.lat, cityMeta.lon, lat, lon)
  const completeness =
    Number(Boolean(address)) +
    Number(Boolean(phone)) +
    Number(Boolean(website)) +
    Number(Boolean(tags.opening_hours))

  return {
    id: `${element.type}/${element.id}`,
    osmType: element.type,
    osmId: element.id,
    title: tags.name || tags.brand || `${category.label} без названия`,
    category: category.code,
    categoryLabel: category.label,
    address: address || 'Адрес не указан в карте',
    phone,
    website,
    openingHours: tags.opening_hours || '',
    description: tags.description || tags['short_description'] || '',
    sourcePage: buildOsmFeatureLink(element.type, element.id),
    coordinates: {
      lat,
      lon,
    },
    boundingbox: bbox,
    mapLinks: buildMapLinks(lat, lon),
    distanceKm: Number(distanceKm.toFixed(2)),
    completeness,
  }
}

function matchSearchText(venue, searchText) {
  if (!searchText) {
    return true
  }

  const normalized = searchText.trim().toLowerCase()

  if (!normalized) {
    return true
  }

  const haystack = [
    venue.title,
    venue.categoryLabel,
    venue.address,
    venue.description,
  ]
    .filter(Boolean)
    .join(' ')
    .toLowerCase()

  return haystack.includes(normalized)
}

function dedupeAndRank(venues, limit) {
  const seen = new Set()
  const unique = []

  for (const venue of venues) {
    const key = `${venue.title.toLowerCase()}|${venue.address.toLowerCase()}|${
      venue.phone
    }`

    if (seen.has(key)) {
      continue
    }

    seen.add(key)
    unique.push(venue)
  }

  return unique
    .sort((left, right) => {
      if (right.completeness !== left.completeness) {
        return right.completeness - left.completeness
      }

      return left.distanceKm - right.distanceKm
    })
    .slice(0, limit)
}

export async function fetchEntertainmentPlaces({
  city = 'Оренбург',
  categories = [],
  limit = DEFAULT_LIMIT,
  searchText = '',
}) {
  const normalizedLimit =
    Number.isFinite(limit) && limit > 0 ? Math.min(Math.trunc(limit), 80) : DEFAULT_LIMIT
  const cityMeta = await geocodeCity(city)

  if (!cityMeta.boundingbox || cityMeta.lat === null || cityMeta.lon === null) {
    throw new Error(`Unable to resolve map bounds for ${city}`)
  }

  const overpassQuery = buildOverpassQuery({
    bbox: cityMeta.boundingbox,
    categories,
  })

  const overpassData = await fetchOverpassJson(overpassQuery)

  const rawElements = Array.isArray(overpassData.elements)
    ? overpassData.elements
    : []

  const venues = rawElements
    .map((element) => normalizeVenue(element, cityMeta))
    .filter(Boolean)
    .filter((venue) => matchSearchText(venue, searchText))

  const prepared = dedupeAndRank(venues, normalizedLimit)

  return {
    source: 'OpenStreetMap / Overpass / Nominatim',
    city: {
      query: city,
      displayName: cityMeta.displayName,
      coordinates: {
        lat: cityMeta.lat,
        lon: cityMeta.lon,
      },
      boundingbox: {
        south: cityMeta.boundingbox[0],
        north: cityMeta.boundingbox[1],
        west: cityMeta.boundingbox[2],
        east: cityMeta.boundingbox[3],
      },
    },
    filters: {
      categories: categories.length ? categories : ['all'],
      limit: normalizedLimit,
      searchText,
    },
    totalFound: rawElements.length,
    returned: prepared.length,
    venues: prepared,
  }
}

export { CATEGORY_DEFINITIONS }
