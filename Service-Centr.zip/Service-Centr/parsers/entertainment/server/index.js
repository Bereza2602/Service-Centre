import http from 'node:http'
import { URL } from 'node:url'
import {
  CATEGORY_DEFINITIONS,
  fetchEntertainmentPlaces,
} from './entertainment.js'

const PORT = Number(process.env.PORT || 3001)

function sendJson(response, statusCode, payload) {
  response.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
  })

  response.end(JSON.stringify(payload))
}

function getCategories(searchParams) {
  return (searchParams.get('categories') || '')
    .split(',')
    .map((category) => category.trim())
    .filter(Boolean)
}

const server = http.createServer(async (request, response) => {
  if (!request.url) {
    sendJson(response, 400, { error: 'Empty request URL' })
    return
  }

  if (request.method === 'OPTIONS') {
    response.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    })
    response.end()
    return
  }

  const url = new URL(request.url, `http://${request.headers.host}`)

  if (request.method === 'GET' && url.pathname === '/api/health') {
    sendJson(response, 200, {
      ok: true,
      source: 'OpenStreetMap / Overpass / Nominatim',
      categories: CATEGORY_DEFINITIONS,
    })
    return
  }

  if (request.method === 'GET' && url.pathname === '/api/search') {
    try {
      const city = url.searchParams.get('city') || 'Оренбург'
      const limitRaw = url.searchParams.get('limit')
      const searchText = url.searchParams.get('searchText') || ''

      const result = await fetchEntertainmentPlaces({
        city,
        categories: getCategories(url.searchParams),
        limit: limitRaw ? Number(limitRaw) : undefined,
        searchText,
      })

      sendJson(response, 200, result)
      return
    } catch (error) {
      sendJson(response, 500, {
        error: 'Failed to fetch entertainment places',
        details: error instanceof Error ? error.message : 'Unknown error',
      })
      return
    }
  }

  sendJson(response, 404, { error: 'Not found' })
})

server.listen(PORT, () => {
  console.log(`Entertainment parser API is running on http://localhost:${PORT}`)
})
