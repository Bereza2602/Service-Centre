import { useMemo, useState, useTransition } from 'react'
import './App.css'

const CATEGORY_OPTIONS = [
  { value: 'all', label: 'Все', hint: 'Максимально широкий поиск развлечений' },
  { value: 'bowling', label: 'Боулинг', hint: 'Дорожки и вечерние игры' },
  { value: 'billiards', label: 'Бильярд', hint: 'Клубы и залы' },
  { value: 'computer_club', label: 'ПК-клубы', hint: 'Компьютерные клубы и киберпространства' },
  { value: 'pinball', label: 'Пинбол', hint: 'Пинбол и игровые автоматы' },
  { value: 'karaoke', label: 'Караоке', hint: 'Залы для компании после работы' },
  { value: 'board_games', label: 'Настолки', hint: 'Антикафе и игровые пространства' },
  { value: 'arcade', label: 'Аркады', hint: 'Игровые центры и развлечения' },
  { value: 'cinema', label: 'Кино', hint: 'Кинотеатры' },
  { value: 'quest', label: 'Квесты', hint: 'Escape rooms и квест-комнаты' },
  { value: 'nightclub', label: 'Клубы', hint: 'Ночные клубы' },
  { value: 'bar', label: 'Бары', hint: 'Бары и пабы' },
  { value: 'hookah', label: 'Кальянные', hint: 'Hookah lounges' },
  { value: 'skating', label: 'Катки', hint: 'Катки и роллердромы' },
  { value: 'trampoline', label: 'Батуты', hint: 'Батутные центры' },
  { value: 'waterpark', label: 'Аква', hint: 'Аквапарки и бассейны' },
]

const DEFAULT_FILTERS = {
  city: 'Екатеринбург',
  searchText: '',
  categories: ['all'],
  limit: '30',
}

function buildQuery(filters) {
  const searchParams = new URLSearchParams()
  searchParams.set('city', filters.city.trim() || 'Екатеринбург')

  if (filters.searchText.trim()) {
    searchParams.set('searchText', filters.searchText.trim())
  }

  if (filters.categories.length) {
    searchParams.set('categories', filters.categories.join(','))
  }

  if (filters.limit.trim()) {
    searchParams.set('limit', filters.limit.trim())
  }

  return searchParams.toString()
}

function formatBbox(boundingbox) {
  if (!boundingbox) {
    return 'Нет bounding box'
  }

  return [
    `S ${boundingbox.south}`,
    `W ${boundingbox.west}`,
    `N ${boundingbox.north}`,
    `E ${boundingbox.east}`,
  ].join(' | ')
}

function formatDistance(distanceKm) {
  if (typeof distanceKm !== 'number') {
    return 'Дистанция не рассчитана'
  }

  return distanceKm < 1
    ? `${Math.round(distanceKm * 1000)} м от центра`
    : `${distanceKm.toFixed(1)} км от центра`
}

function App() {
  const [filters, setFilters] = useState(DEFAULT_FILTERS)
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')
  const [isPending, startTransition] = useTransition()

  const queryPreview = useMemo(() => buildQuery(filters), [filters])

  async function handleSearch(event) {
    event.preventDefault()
    setError('')

    try {
      const response = await fetch(`/api/search?${buildQuery(filters)}`)
      const payload = await response.json()

      if (!response.ok) {
        throw new Error(payload.details || payload.error || 'Search failed')
      }

      startTransition(() => {
        setResult(payload)
      })
    } catch (requestError) {
      setResult(null)
      setError(
        requestError instanceof Error
          ? requestError.message
          : 'Не удалось получить реальные места отдыха',
      )
    }
  }

  function toggleCategory(category) {
    setFilters((current) => {
      if (category === 'all') {
        return {
          ...current,
          categories: ['all'],
        }
      }

      const nextCategories = current.categories.includes(category)
        ? current.categories.filter((value) => value !== category && value !== 'all')
        : [...current.categories.filter((value) => value !== 'all'), category]

      return {
        ...current,
        categories: nextCategories.length ? nextCategories : ['all'],
      }
    })
  }

  return (
    <main className="shell">
      <section className="hero-panel">
        <div className="hero-copy">
          <p className="eyebrow">ParserDosug</p>
          <h1>Большой парсер развлечений, который можно дальше ставить на домен</h1>
          <p className="lead">
            Сервис собирает реальные места отдыха по открытым картам и подходит как
            база под будущую витрину всех ваших парсеров. Поиск теперь шире:
            боулинг, ПК-клубы, кино, квесты, клубы, бары, кальянные, батуты,
            аквапарки и другие точки.
          </p>
          <div className="status-row">
            <span className="status-pill">Источник: OpenStreetMap</span>
            <span className="status-pill">API: /api/search</span>
            <span className="status-pill">Данные: адрес, телефон, сайт, bbox, карты</span>
          </div>
        </div>

        <form className="search-panel" onSubmit={handleSearch}>
          <div className="field">
            <label htmlFor="city">Город</label>
            <input
              id="city"
              list="city-suggestions"
              value={filters.city}
              onChange={(event) =>
                setFilters((current) => ({
                  ...current,
                  city: event.target.value,
                }))
              }
              placeholder="Например, Екатеринбург"
            />
            <datalist id="city-suggestions">
              <option value="Екатеринбург" />
              <option value="Москва" />
              <option value="Санкт-Петербург" />
              <option value="Казань" />
              <option value="Челябинск" />
              <option value="Уфа" />
              <option value="Новосибирск" />
            </datalist>
            <small>Можно вводить любой город.</small>
          </div>

          <div className="field">
            <label htmlFor="searchText">Текстовый поиск</label>
            <input
              id="searchText"
              value={filters.searchText}
              onChange={(event) =>
                setFilters((current) => ({
                  ...current,
                  searchText: event.target.value,
                }))
              }
              placeholder="Например, боулинг, cyber, кино, hookah"
            />
            <small>Фильтрует результаты по названию, адресу и описанию.</small>
          </div>

          <div className="field">
            <span className="field-label">Что искать</span>
            <div className="deal-switch">
              {CATEGORY_OPTIONS.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  className={
                    filters.categories.includes(option.value)
                      ? 'deal-option active'
                      : 'deal-option'
                  }
                  onClick={() => toggleCategory(option.value)}
                >
                  <span>{option.label}</span>
                  <small>{option.hint}</small>
                </button>
              ))}
            </div>
          </div>

          <div className="field">
            <label htmlFor="limit">Сколько мест вернуть</label>
            <input
              id="limit"
              inputMode="numeric"
              value={filters.limit}
              onChange={(event) =>
                setFilters((current) => ({
                  ...current,
                  limit: event.target.value.replace(/[^\d]/g, ''),
                }))
              }
              placeholder="30"
            />
          </div>

          <button className="submit-button" type="submit" disabled={isPending}>
            {isPending ? 'Ищу живые места...' : 'Найти места отдыха'}
          </button>

          <div className="query-preview">
            <span>Запрос:</span>
            <code>/api/search?{queryPreview}</code>
          </div>
        </form>
      </section>

      <section className="results-panel">
        <div className="results-header">
          <div>
            <p className="section-label">Результаты</p>
            <h2>Живые карточки для будущего большого проекта</h2>
          </div>
          {result ? (
            <div className="results-meta">
              <span>Найдено в источнике: {result.totalFound}</span>
              <span>Показано: {result.returned}</span>
              <span>Город: {result.city.displayName}</span>
            </div>
          ) : null}
        </div>

        {result ? (
          <div className="city-summary">
            <div>
              <strong>Центр поиска:</strong> {result.city.coordinates.lat},{' '}
              {result.city.coordinates.lon}
            </div>
            <div>
              <strong>Границы города:</strong> {formatBbox(result.city.boundingbox)}
            </div>
          </div>
        ) : null}

        {error ? <div className="message error">{error}</div> : null}

        {!result && !error ? (
          <div className="message empty">
            По умолчанию включен широкий режим «Все». Можно просто выбрать город и
            запустить поиск.
          </div>
        ) : null}

        {result && !result.venues.length ? (
          <div className="message empty">
            По этим фильтрам места не нашлись. Попробуйте убрать текстовый фильтр
            или оставить категорию «Все».
          </div>
        ) : null}

        <div className="cards-grid">
          {result?.venues.map((venue) => (
            <article className="offer-card" key={venue.id}>
              <div className="venue-map">
                <div className="venue-map-label">{venue.categoryLabel}</div>
                <div className="venue-coordinates">
                  <span>lat {venue.coordinates.lat}</span>
                  <span>lon {venue.coordinates.lon}</span>
                </div>
                <p className="bbox-label">Bounding box</p>
                <p className="bbox-value">{formatBbox(venue.boundingbox)}</p>
              </div>

              <div className="offer-body">
                <div className="offer-main">
                  <div className="title-row">
                    <h3>{venue.title}</h3>
                    <span className="quality-pill">
                      Полезность: {venue.completeness}/4
                    </span>
                  </div>
                  <p className="offer-address">{venue.address}</p>
                  <p className="offer-complex">{formatDistance(venue.distanceKm)}</p>
                  <p className="offer-description">
                    {venue.description || 'Карточка подготовлена для витрины и базы.'}
                  </p>
                </div>

                <div className="info-grid">
                  <div className="info-item">
                    <span>Телефон</span>
                    <strong>{venue.phone || 'Не указан'}</strong>
                  </div>
                  <div className="info-item">
                    <span>Часы работы</span>
                    <strong>{venue.openingHours || 'Не указаны'}</strong>
                  </div>
                  <div className="info-item">
                    <span>Сайт</span>
                    {venue.website ? (
                      <strong>
                        <a href={venue.website} target="_blank" rel="noreferrer">
                          {venue.website}
                        </a>
                      </strong>
                    ) : (
                      <strong>Не указан</strong>
                    )}
                  </div>
                  <div className="info-item">
                    <span>OSM ID</span>
                    <strong>{venue.osmType}/{venue.osmId}</strong>
                  </div>
                </div>

                <div className="offer-footer">
                  <div className="tag-row">
                    <span className="tag">{venue.categoryLabel}</span>
                    {venue.phone ? <span className="tag">Есть телефон</span> : null}
                    {venue.website ? <span className="tag">Есть сайт</span> : null}
                    {venue.openingHours ? <span className="tag">Есть часы работы</span> : null}
                  </div>

                  <div className="offer-actions">
                    <a href={venue.sourcePage} target="_blank" rel="noreferrer">
                      OSM объект
                    </a>
                    <a href={venue.mapLinks.openstreetmap} target="_blank" rel="noreferrer">
                      OSM карта
                    </a>
                    <a href={venue.mapLinks.yandex} target="_blank" rel="noreferrer">
                      Яндекс Карты
                    </a>
                    <a href={venue.mapLinks.google} target="_blank" rel="noreferrer">
                      Google Maps
                    </a>
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </main>
  )
}

export default App
