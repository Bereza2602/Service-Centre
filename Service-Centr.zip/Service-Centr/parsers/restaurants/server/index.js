import http from 'node:http'
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { searchPlaces } from './two-gis.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const publicDir = path.resolve(__dirname, '../public')
const PORT = Number(process.env.PORT || 3017)

const MIME_TYPES = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
}

function sendJson(response, statusCode, payload) {
  response.writeHead(statusCode, {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json; charset=utf-8',
  })

  response.end(JSON.stringify(payload))
}

async function sendFile(response, pathname) {
  const normalizedPath = pathname === '/' ? '/index.html' : pathname
  const resolvedPath = path.resolve(publicDir, `.${normalizedPath}`)

  if (!resolvedPath.startsWith(publicDir)) {
    response.writeHead(403)
    response.end('Forbidden')
    return
  }

  try {
    const file = await readFile(resolvedPath)
    response.writeHead(200, {
      'Content-Type': MIME_TYPES[path.extname(resolvedPath)] ?? 'application/octet-stream',
    })
    response.end(file)
  } catch {
    response.writeHead(404)
    response.end('Not found')
  }
}

function getSearchParams(url) {
  const city = (url.searchParams.get('city') || 'ekaterinburg').trim()
  const query = (url.searchParams.get('query') || '').trim()
  const profile = (url.searchParams.get('profile') || 'universal').trim()
  const limit = Number(url.searchParams.get('limit') || '8')
  const withWebsitePhones = url.searchParams.get('withWebsitePhones') !== '0'

  return {
    city,
    query,
    profile,
    limit: Number.isFinite(limit) ? limit : 8,
    withWebsitePhones,
  }
}

const server = http.createServer(async (request, response) => {
  if (!request.url) {
    sendJson(response, 400, { error: 'Пустой URL запроса' })
    return
  }

  if (request.method === 'OPTIONS') {
    response.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    })
    response.end()
    return
  }

  const url = new URL(request.url, `http://${request.headers.host}`)

  if (request.method === 'GET' && url.pathname === '/api/health') {
    sendJson(response, 200, { ok: true })
    return
  }

  if (request.method === 'GET' && url.pathname === '/api/search') {
    try {
      const result = await searchPlaces(getSearchParams(url))
      sendJson(response, 200, result)
      return
    } catch (error) {
      sendJson(response, 500, {
        error: 'Не удалось получить данные из 2GIS',
        details: error instanceof Error ? error.message : 'Unknown error',
      })
      return
    }
  }

  if (request.method === 'GET') {
    await sendFile(response, url.pathname)
    return
  }

  response.writeHead(405)
  response.end('Method not allowed')
})

server.listen(PORT, () => {
  console.log(`Live parser is running on http://localhost:${PORT}`)
})
