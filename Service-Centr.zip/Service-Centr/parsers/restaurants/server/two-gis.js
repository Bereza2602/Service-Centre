const BASE_URL = 'https://2gis.ru'
const DEFAULT_LIMIT = 8
const MAX_LIMIT = 12

const HTML_ENTITY_MAP = {
  '&amp;': '&',
  '&apos;': "'",
  '&#39;': "'",
  '&gt;': '>',
  '&lt;': '<',
  '&nbsp;': ' ',
  '&ndash;': '-',
  '&mdash;': '-',
  '&quot;': '"',
}

const STOP_HOSTS = [
  '2gis.ru',
  '2gis.com',
  'api.2gis.com',
  'api.2gis.ru',
  'go.2gis.com',
  'redirect.2gis.com',
  'link.2gis.ru',
  'keys.api.2gis.com',
  'styles.api.2gis.com',
  'share.api.2gis.ru',
  'stat.api.2gis.ru',
  'catalog.api.2gis.ru',
  'outsource.api.2gis.com',
  'advisor.api.2gis.ru',
  'checkscan.ru',
  'chk.sc',
  'taplink.cc',
  'taplink.ws',
  'tilda.ws',
  'wa.me',
  'api.whatsapp.com',
  't.me',
  'vk.com',
  'instagram.com',
  'facebook.com',
  'youtube.com',
  'yandex.ru',
]

const STOP_URL_PARTS = [
  'checkscan',
  'qr-menu',
  'qrmenu',
  'menu',
  'taplink',
  'linkin',
  'redirect',
  'roulette',
  'wheel',
  'scan',
]

const RESTAURANT_INCLUDE_KEYWORDS = [
  'restaurant',
  'restaurants',
  'cafe',
  'coffee shop',
  'bar',
  'pub',
  'pizza',
  'pizzeria',
  'sushi',
  'food court',
  'burger',
  'grill',
  'steak',
  'bakery',
  'bistro',
  'canteen',
  'dining',
  'ресторан',
  'кафе',
  'кофейня',
  'бар',
  'пицца',
  'пиццерия',
  'суши',
  'бургер',
  'гриль',
  'стейк',
  'пекарня',
  'булочная',
  'кондитерская',
  'бистро',
  'столовая',
  'фудкорт',
]

const RESTAURANT_EXCLUDE_KEYWORDS = [
  'hotel',
  'hostel',
  'dentist',
  'pharmacy',
  'clinic',
  'car wash',
  'beauty salon',
  'hair salon',
  'гостиница',
  'отель',
  'хостел',
  'стоматолог',
  'аптека',
  'клиника',
  'автомойка',
  'салон красоты',
  'парикмахер',
]

const SERVICE_CODE_MAP = {
  takeaway: 'навынос',
  delivery: 'доставка',
}

const QUERY_FALLBACKS = [
  [/рестораны?\s+и\s+кафе/gi, 'restaurant'],
  [/ресторан(ы|ов|ам|ами|ах)?/gi, 'restaurant'],
  [/кафе/gi, 'cafe'],
  [/кофе(йня|йни|ен|йню|еню)?/gi, 'coffee shop'],
  [/бар(ы|ов|ам|ами|ах)?/gi, 'bar'],
  [/бургер(ы|ных|ная|ную|ные)?/gi, 'burger'],
  [/пицц(а|ы|ери[яю]|ерию|ерии)/gi, 'pizza'],
  [/суши/gi, 'sushi'],
  [/стоматолог(ия|ии|ию|ией)?/gi, 'dentist'],
  [/аптек(а|и|у|ой|е)?/gi, 'pharmacy'],
  [/автомойк(а|и|у|ой|е)?/gi, 'car wash'],
  [/салон красоты/gi, 'beauty salon'],
  [/парикмахерск(ая|ие|ую|ой)?/gi, 'hair salon'],
  [/гостиниц(а|ы|у|е|ой)?/gi, 'hotel'],
  [/отел(ь|и|я|ю|ем)?/gi, 'hotel'],
  [/клиник(а|и|у|е|ой)?/gi, 'clinic'],
  [/фитнес( клуб)?/gi, 'fitness club'],
]

const SEARCH_PROFILES = {
  universal: {
    label: 'Универсальный поиск',
    defaultQuery: '',
    extraCandidates: [],
  },
  restaurants: {
    label: 'Рестораны и кафе',
    defaultQuery: 'рестораны и кафе',
    extraCandidates: ['restaurant', 'cafe', 'coffee shop', 'bar', 'pizza', 'sushi'],
  },
}

function decodeHtmlEntities(value = '') {
  return value
    .replace(/&#(\d+);/g, (_, code) => String.fromCodePoint(Number(code)))
    .replace(/&#x([a-f0-9]+);/gi, (_, code) =>
      String.fromCodePoint(Number.parseInt(code, 16)),
    )
    .replace(
      /&amp;|&apos;|&#39;|&gt;|&lt;|&nbsp;|&ndash;|&mdash;|&quot;/g,
      (entity) => HTML_ENTITY_MAP[entity] ?? entity,
    )
}

function stripTags(value = '') {
  return decodeHtmlEntities(value)
    .replace(/<br\s*\/?>/gi, ', ')
    .replace(/<[^>]*>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

function parseMeta(html, name) {
  const patterns = [
    new RegExp(`<meta[^>]+property=["']${name}["'][^>]+content=["']([^"']*)["']`, 'i'),
    new RegExp(`<meta[^>]+name=["']${name}["'][^>]+content=["']([^"']*)["']`, 'i'),
  ]

  for (const pattern of patterns) {
    const match = html.match(pattern)
    if (match) {
      return decodeHtmlEntities(match[1])
    }
  }

  return ''
}

function extractFirst(html, pattern) {
  const match = html.match(pattern)
  return match ? match[1] : ''
}

function normalize2gisUrl(url = '', city = '') {
  if (!url) return ''
  if (url.startsWith('http')) return decodeHtmlEntities(url)
  if (url.startsWith('/')) return `${BASE_URL}${url}`
  if (city) return `${BASE_URL}/${city}/${url.replace(/^\/+/, '')}`
  return `${BASE_URL}/${url.replace(/^\/+/, '')}`
}

async function fetchHtml(url) {
  const response = await fetch(url, {
    headers: {
      accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'accept-language': 'ru-RU,ru;q=0.9,en;q=0.8',
      'user-agent':
        'Mozilla/5.0 (Windows NT; Windows NT 10.0; ru-RU) WindowsPowerShell/5.1.22621.608',
    },
  })

  if (!response.ok) {
    throw new Error(`Источник вернул ${response.status} для ${url}`)
  }

  return response.text()
}

function buildSearchUrl({ city, query }) {
  return `${BASE_URL}/${encodeURIComponent(city)}/search/${encodeURIComponent(query)}`
}

function buildMapSearchUrl({ title, address, city }) {
  const rawQuery = [title, address, city].filter(Boolean).join(', ')
  return `${BASE_URL}/${encodeURIComponent(city)}/search/${encodeURIComponent(rawQuery)}`
}

function buildYandexMapsUrl({ title, address, city, coordinates }) {
  const rawQuery = [title, address, city].filter(Boolean).join(', ')

  if (coordinates && Number.isFinite(coordinates.lat) && Number.isFinite(coordinates.lon)) {
    const latStr = coordinates.lat.toFixed(6)
    const lonStr = coordinates.lon.toFixed(6)
    return `https://yandex.ru/maps/?ll=${lonStr}%2C${latStr}&z=17&pt=${lonStr},${latStr},pm2rdm&text=${encodeURIComponent(rawQuery)}`
  }

  return `https://yandex.ru/maps/?text=${encodeURIComponent(rawQuery)}`
}

function transliterate(value = '') {
  const map = {
    а: 'a',
    б: 'b',
    в: 'v',
    г: 'g',
    д: 'd',
    е: 'e',
    ё: 'e',
    ж: 'zh',
    з: 'z',
    и: 'i',
    й: 'y',
    к: 'k',
    л: 'l',
    м: 'm',
    н: 'n',
    о: 'o',
    п: 'p',
    р: 'r',
    с: 's',
    т: 't',
    у: 'u',
    ф: 'f',
    х: 'h',
    ц: 'ts',
    ч: 'ch',
    ш: 'sh',
    щ: 'sch',
    ъ: '',
    ы: 'y',
    ь: '',
    э: 'e',
    ю: 'yu',
    я: 'ya',
  }

  return value
    .toLowerCase()
    .split('')
    .map((char) => map[char] ?? char)
    .join('')
    .replace(/[^a-z0-9\s-]/g, ' ')
    .replace(/\s+/g, ' ')
    .trim()
}

function buildSearchCandidates(query = '') {
  const normalized = query.trim()
  const candidates = [normalized]

  for (const [pattern, replacement] of QUERY_FALLBACKS) {
    if (pattern.test(normalized)) {
      candidates.push(normalized.replace(pattern, replacement))
    }
  }

  const transliterated = transliterate(normalized)
  if (transliterated && transliterated !== normalized) {
    candidates.push(transliterated)
  }

  return [...new Set(candidates.filter(Boolean))]
}

function getSearchProfile(profile = 'universal') {
  return SEARCH_PROFILES[profile] || SEARCH_PROFILES.universal
}

function getProfileCandidates({ profile, query }) {
  const selectedProfile = getSearchProfile(profile)
  const seedQuery = query?.trim() || selectedProfile.defaultQuery
  const candidates = buildSearchCandidates(seedQuery)

  for (const extraCandidate of selectedProfile.extraCandidates) {
    candidates.push(extraCandidate)
  }

  return {
    profileKey: profile in SEARCH_PROFILES ? profile : 'universal',
    profileLabel: selectedProfile.label,
    querySeed: seedQuery,
    candidates: [...new Set(candidates.filter(Boolean))],
  }
}

function extractFirmCandidates(searchHtml, city) {
  const matches = Array.from(
    searchHtml.matchAll(/<a href="(\/[^"]+\/firm\/\d+[^"]*)"[^>]*>([\s\S]{0,3000}?)<\/a>/gi),
    (match) => ({
      title: stripTags(match[2]),
      url: normalize2gisUrl(match[1], city),
    }),
  )

  const seen = new Set()

  return matches.filter((item) => {
    if (!item.url || seen.has(item.url) || !item.title) {
      return false
    }

    seen.add(item.url)
    return true
  })
}

function extractPhones(html) {
  const phones = Array.from(html.matchAll(/href="tel:([^"]+)"/gi), (match) =>
    decodeHtmlEntities(match[1]).trim(),
  )

  return [...new Set(phones)]
}

function parseRating(raw = '') {
  const match = raw.match(/Оценка\s*([0-9]+(?:[.,][0-9]+)?)/i)
  return match ? Number(match[1].replace(',', '.')) : null
}

function parseReviewCount(raw = '') {
  const match = raw.match(/([0-9\s]+)\s+отзыв/i)
  if (!match) return null
  const numeric = match[1].replace(/[^\d]/g, '')
  return numeric ? Number(numeric) : null
}

function parseCoordinates(imageUrl = '') {
  const match = imageUrl.match(/center=([0-9.%-]+)%2C([0-9.%-]+)/i)
  if (!match) return null

  return {
    lon: Number(decodeURIComponent(match[1])),
    lat: Number(decodeURIComponent(match[2])),
  }
}

function unwrapRedirectUrl(url = '') {
  const cleanUrl = decodeHtmlEntities(url)
  const directMatch = cleanUrl.match(/https?:\/\/[^\s"'<>]+/i)
  if (!cleanUrl.startsWith('http') && directMatch) {
    return decodeHtmlEntities(directMatch[0])
  }

  try {
    const parsed = new URL(cleanUrl)
    const nestedParam = ['url', 'target', 'to', 'u', 'redirect', 'redirect_url']
      .map((key) => parsed.searchParams.get(key))
      .find((value) => value && /^https?:\/\//i.test(value))

    if (nestedParam) {
      return decodeHtmlEntities(nestedParam)
    }
  } catch {
    return cleanUrl
  }

  const parts = cleanUrl.split('?')
  const tail = decodeHtmlEntities(parts.at(-1) || '')
  if (tail.startsWith('http://') || tail.startsWith('https://')) {
    return tail
  }

  return cleanUrl
}

function isOfficialWebsite(candidateUrl = '') {
  try {
    const parsed = new URL(candidateUrl)
    const host = parsed.hostname.replace(/^www\./i, '').toLowerCase()
    const normalizedUrl = `${host}${parsed.pathname}${parsed.search}`.toLowerCase()

    if (STOP_HOSTS.some((blockedHost) => host === blockedHost || host.endsWith(`.${blockedHost}`))) {
      return false
    }

    if (STOP_URL_PARTS.some((part) => normalizedUrl.includes(part))) {
      return false
    }

    return true
  } catch {
    return false
  }
}

function extractExternalLinks(html) {
  const rawLinks = Array.from(html.matchAll(/href="([^"]+)"/gi), (match) =>
    unwrapRedirectUrl(match[1]),
  )

  const unique = []
  const seen = new Set()

  for (const link of rawLinks) {
    if (!link.startsWith('http')) continue
    if (seen.has(link)) continue
    seen.add(link)
    unique.push(link)
  }

  return unique
}

function pickOfficialWebsite(links) {
  const candidates = links.filter((link) => isOfficialWebsite(link))

  if (!candidates.length) {
    return ''
  }

  return candidates.sort((left, right) => scoreWebsiteCandidate(right) - scoreWebsiteCandidate(left))[0]
}

function scoreWebsiteCandidate(candidateUrl = '') {
  try {
    const parsed = new URL(candidateUrl)
    const host = parsed.hostname.replace(/^www\./i, '').toLowerCase()
    const path = parsed.pathname.replace(/\/+$/, '') || '/'
    let score = 0

    if (!parsed.search) score += 2
    if (path === '/') score += 4
    if (path.split('/').filter(Boolean).length <= 1) score += 2
    if (!host.includes('menu') && !host.includes('scan')) score += 2
    if (/\.(ru|com|net|org|cafe|rest|restaurant)$/i.test(host)) score += 1

    return score
  } catch {
    return Number.NEGATIVE_INFINITY
  }
}

function parseCategories(title = '') {
  const parts = title.split(',').map((part) => part.trim()).filter(Boolean)
  return {
    title: parts[0] || title,
    subtitle: parts[1] || '',
  }
}

function extractAddressFromTitle(title = '') {
  const normalized = title.replace(/\s+—\s+2ГИС$/i, '').trim()
  const parts = normalized.split(',').map((part) => part.trim()).filter(Boolean)
  if (parts.length <= 2) return ''
  return parts.slice(2).join(', ')
}

function extractAveragePrice(html) {
  const desc = parseMeta(html, 'og:description') || parseMeta(html, 'description')
  const match = desc.match(/чек\s*([0-9\s]+)\s*₽/i)
  return match ? Number(match[1].replace(/\s/g, '')) : null
}

function extractCuisine(html) {
  const desc = parseMeta(html, 'description')
  const match = desc.match(/([^,]+?)\s*кухня/i)
  return match ? match[1].trim() : ''
}

function extractServices(html) {
  const desc = parseMeta(html, 'description')
  const services = []
  if (/навынос/i.test(desc)) services.push('навынос')
  if (/доставк/i.test(desc)) services.push('доставка')
  if (/летняя веранда/i.test(desc)) services.push('веранда')
  if (/бизнес-ланч/i.test(desc)) services.push('бизнес-ланч')
  if (/завтрак/i.test(desc)) services.push('завтраки')
  if (/винная карта/i.test(desc)) services.push('винная карта')
  return services
}

function extractImage(html) {
  const ogImage = parseMeta(html, 'og:image') || parseMeta(html, 'twitter:image')
  return decodeHtmlEntities(ogImage)
}

function extractJsonAfterMarker(html, marker) {
  const markerIndex = html.indexOf(marker)
  if (markerIndex === -1) return null

  const startIndex = markerIndex + marker.length
  const opener = html[startIndex]
  const closer = opener === '{' ? '}' : opener === '[' ? ']' : ''
  if (!closer) return null

  let depth = 0
  let inString = false
  let escaping = false

  for (let index = startIndex; index < html.length; index += 1) {
    const char = html[index]

    if (inString) {
      if (escaping) {
        escaping = false
      } else if (char === '\\') {
        escaping = true
      } else if (char === '"') {
        inString = false
      }
      continue
    }

    if (char === '"') {
      inString = true
      continue
    }

    if (char === opener) {
      depth += 1
    } else if (char === closer) {
      depth -= 1

      if (depth === 0) {
        try {
          return JSON.parse(html.slice(startIndex, index + 1))
        } catch {
          return null
        }
      }
    }
  }

  return null
}

function extractBestPhoto(html) {
  const externalContent = extractJsonAfterMarker(html, '"external_content":')
  const mainPhotoUrl = Array.isArray(externalContent)
    ? externalContent.find((item) => item?.main_photo_url)?.main_photo_url
    : ''

  return mainPhotoUrl || extractImage(html)
}

function formatHours(schedule = {}) {
  const order = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
  const labels = {
    Mon: 'Пн',
    Tue: 'Вт',
    Wed: 'Ср',
    Thu: 'Чт',
    Fri: 'Пт',
    Sat: 'Сб',
    Sun: 'Вс',
  }

  const entries = order.map((day) => {
    const hours = schedule?.[day]?.working_hours
    if (!Array.isArray(hours) || !hours.length) {
      return { label: labels[day], value: 'выходной' }
    }

    return {
      label: labels[day],
      value: hours.map((item) => `${item.from}-${item.to}`).join(', '),
    }
  })

  const groups = []
  for (const entry of entries) {
    const last = groups.at(-1)
    if (last && last.value === entry.value) {
      last.end = entry.label
      continue
    }

    groups.push({
      start: entry.label,
      end: entry.label,
      value: entry.value,
    })
  }

  return groups
    .map((group) =>
      `${group.start}${group.start === group.end ? '' : `-${group.end}`}: ${group.value}`,
    )
    .join('; ')
}

function extractWebsitePhoneCandidates(html) {
  const candidates = []

  const telLinks = Array.from(html.matchAll(/href=["']tel:([^"']+)["']/gi), (match) =>
    decodeHtmlEntities(match[1]).trim(),
  )
  candidates.push(...telLinks)

  const plainTextMatches = Array.from(
    html.matchAll(
      /(?:тел|телефон|phone|contact|call|позвонить|звонить|контакт)\s*[:：]?\s*([\+7]?[\s\-\(\)\d]{7,20})/gi,
    ),
    (match) => {
      const raw = match[1].trim()
      const cleaned = raw.replace(/[^\d+]/g, '')
      return cleaned.length >= 10 && cleaned.length <= 15 ? raw : ''
    },
  )
  candidates.push(...plainTextMatches)

  const standalonePhones = Array.from(
    html.matchAll(
      /(?<!\d)((?:8|[\+]?7)[\s\-]?[\(]?[\d]{3}[\)]?[\s\-]?[\d]{3}[\s\-]?[\d]{2}[\s\-]?[\d]{2})(?!\d)/g,
    ),
    (match) => {
      const raw = match[1].trim()
      const cleaned = raw.replace(/[^\d+]/g, '')
      return cleaned.length >= 10 && cleaned.length <= 15 ? raw : ''
    },
  )
  candidates.push(...standalonePhones)

  return [...new Set(candidates.filter(Boolean))]
}

async function fetchOfficialWebsitePhone(websiteUrl) {
  if (!websiteUrl) return ''

  try {
    const html = await fetchHtml(websiteUrl)
    const phones = extractWebsitePhoneCandidates(html)
    return phones[0] || ''
  } catch {
    return ''
  }
}

async function parseFirmPage({ city, firmUrl, withWebsitePhones }) {
  const html = await fetchHtml(firmUrl)
  const titleMeta = parseMeta(html, 'og:title')
  const descMeta = parseMeta(html, 'description')
  const socialProofMeta = parseMeta(html, 'og:description')
  const cleanedTitle = titleMeta.replace(/\s+—\s+2ГИС$/i, '')
  const { title, subtitle } = parseCategories(cleanedTitle)
  const address = extractAddressFromTitle(cleanedTitle) || extractAddressFromTitle(descMeta)
  const imageUrl = extractBestPhoto(html)
  const coordinates = parseCoordinates(extractImage(html))
  const links = extractExternalLinks(html)
  const website = pickOfficialWebsite(links)
  const websitePhone = withWebsitePhones ? await fetchOfficialWebsitePhone(website) : ''
  const schedule = extractJsonAfterMarker(html, '"schedule":')
  const openingHours = formatHours(schedule || {})
  const averagePrice = extractAveragePrice(html)
  const cuisine = extractCuisine(html)
  const services = extractServices(html)

  return {
    id: extractFirst(firmUrl, /firm\/(\d+)/i) || firmUrl,
    title,
    subtitle,
    address,
    description: descMeta,
    rating: parseRating(socialProofMeta),
    reviewCount: parseReviewCount(socialProofMeta),
    phone: extractPhones(html)[0] || '',
    openingHours,
    website,
    websitePhone,
    averagePrice,
    cuisine,
    services,
    detailUrl: firmUrl,
    mapUrl: buildMapSearchUrl({ title, address, city }),
    yandexMapUrl: buildYandexMapsUrl({ title, address, city, coordinates }),
    imageUrl,
    source: '2GIS',
    coordinates,
  }
}

function normalizeProfileText(value = '') {
  return value.toLowerCase().replace(/\s+/g, ' ').trim()
}

function isRestaurantProfileMatch(item) {
  const haystack = normalizeProfileText(
    [item.title, item.subtitle, item.description].filter(Boolean).join(' '),
  )

  if (!haystack) {
    return false
  }

  const hasRestaurantKeyword = RESTAURANT_INCLUDE_KEYWORDS.some((keyword) =>
    haystack.includes(keyword),
  )

  if (!hasRestaurantKeyword) {
    return false
  }

  return !RESTAURANT_EXCLUDE_KEYWORDS.some((keyword) => haystack.includes(keyword))
}

function filterItemsByProfile(items, profile) {
  if (profile !== 'restaurants') {
    return items
  }

  return items.filter((item) => isRestaurantProfileMatch(item))
}

async function mapWithConcurrency(items, limit, iteratee) {
  const results = new Array(items.length)
  let index = 0

  async function worker() {
    while (index < items.length) {
      const currentIndex = index
      index += 1
      results[currentIndex] = await iteratee(items[currentIndex], currentIndex)
    }
  }

  const workers = Array.from({ length: Math.min(limit, items.length) }, () => worker())
  await Promise.all(workers)
  return results
}

export async function searchPlaces({
  city = 'ekaterinburg',
  query = '',
  profile = 'universal',
  limit = DEFAULT_LIMIT,
  withWebsitePhones = true,
  services = [],
}) {
  const normalizedLimit = Math.max(1, Math.min(Number(limit) || DEFAULT_LIMIT, MAX_LIMIT))
  const { profileKey, profileLabel, querySeed, candidates } = getProfileCandidates({
    profile,
    query,
  })

  let searchUrl = ''
  let firms = []
  let queryUsed = querySeed
  const candidateLimit =
    profileKey === 'restaurants'
      ? Math.max(normalizedLimit, Math.min(normalizedLimit * 3, 24))
      : normalizedLimit

  for (const candidate of candidates) {
    searchUrl = buildSearchUrl({ city, query: candidate })
    const searchHtml = await fetchHtml(searchUrl)
    firms = extractFirmCandidates(searchHtml, city).slice(0, candidateLimit)

    if (firms.length) {
      queryUsed = candidate
      break
    }
  }

  if (!firms.length) {
    return {
      city,
      query: querySeed,
      queryUsed,
      profile: profileKey,
      profileLabel,
      count: 0,
      source: '2GIS',
      searchUrl,
      items: [],
    }
  }

  const items = (
    await mapWithConcurrency(firms, 3, async (firm) =>
      parseFirmPage({
        city,
        firmUrl: firm.url,
        withWebsitePhones,
      }),
    )
  ).filter(Boolean)

  let filteredItems = filterItemsByProfile(items, profileKey)
  if (services.length > 0) {
    const mapped = services.map(s => SERVICE_CODE_MAP[s] || s)
    filteredItems = filteredItems.filter(item => {
      if (!Array.isArray(item.services)) return false
      return mapped.some(s => item.services.includes(s))
    })
  }
  filteredItems = filteredItems.slice(0, normalizedLimit)

  return {
    city,
    query: querySeed,
    queryUsed,
    profile: profileKey,
    profileLabel,
    count: filteredItems.length,
    source: '2GIS',
    searchUrl,
    items: filteredItems,
  }
}
