const form = document.getElementById('search-form')
const resultsNode = document.getElementById('results')
const messageNode = document.getElementById('message')
const statsNode = document.getElementById('stats')
const submitButton = document.getElementById('submit-button')
const queryPreviewNode = document.getElementById('query-preview')

const fields = {
  city: document.getElementById('city'),
  limit: document.getElementById('limit'),
  profile: document.getElementById('profile'),
  query: document.getElementById('query'),
  withWebsitePhones: document.getElementById('withWebsitePhones'),
}

const PROFILE_DEFAULTS = {
  restaurants: {
    placeholder: 'рестораны и кафе',
    defaultQuery: 'рестораны и кафе',
    button: 'Искать рестораны',
    loading: 'Выполняется усиленный поиск ресторанов и кафе...',
    empty: 'По вашему запросу рестораны и кафе не найдены.',
  },
  universal: {
    placeholder: 'ресторан, кафе, стоматология, аптека, автомойка',
    defaultQuery: '',
    button: 'Искать организации',
    loading: 'Выполняется живой поиск организаций...',
    empty: 'По вашему запросу организации не найдены.',
  },
}

function escapeHtml(value = '') {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
}

function getProfileConfig() {
  return PROFILE_DEFAULTS[fields.profile.value] || PROFILE_DEFAULTS.universal
}

function buildQueryString() {
  const profileConfig = getProfileConfig()
  const params = new URLSearchParams()
  const query = fields.query.value.trim() || profileConfig.defaultQuery

  params.set('profile', fields.profile.value)
  params.set('city', fields.city.value)
  params.set('limit', fields.limit.value || '6')

  if (query) {
    params.set('query', query)
  }

  if (!fields.withWebsitePhones.checked) {
    params.set('withWebsitePhones', '0')
  }

  return params.toString()
}

function updateProfileUi() {
  const profileConfig = getProfileConfig()
  fields.query.placeholder = profileConfig.placeholder
  submitButton.textContent = profileConfig.button
  updatePreview()
}

function updatePreview() {
  queryPreviewNode.textContent = `/api/search?${buildQueryString()}`
}

function setMessage(text, type = '') {
  messageNode.className = `message ${type}`.trim()
  messageNode.textContent = text
}

function renderStats(payload) {
  statsNode.innerHTML = payload
    ? `
      <span>Источник: ${escapeHtml(payload.source)}</span>
      <span>Профиль: ${escapeHtml(payload.profileLabel)}</span>
      <span>Найдено: ${payload.count}</span>
      <span>Ключ поиска: ${escapeHtml(payload.queryUsed || payload.query || 'авто')}</span>
      <a href="${escapeHtml(payload.searchUrl)}" target="_blank" rel="noreferrer">Открыть поиск в 2GIS</a>
    `
    : ''
}

function renderResults(items) {
  resultsNode.innerHTML = items
    .map(
      (item) => `
        <article class="card">
          <div class="card-media">
            ${
              item.imageUrl
                ? `<img src="${escapeHtml(item.imageUrl)}" alt="${escapeHtml(item.title)}" loading="lazy" />`
                : '<div class="fallback-media">Нет фото</div>'
            }
            ${item.rating ? `<div class="rating-badge">★ ${item.rating.toFixed(1)}</div>` : ''}
          </div>

          <div class="card-body">
            <div class="title-row">
              <div>
                <h3>${escapeHtml(item.title)}</h3>
                ${item.subtitle ? `<p class="subtitle">${escapeHtml(item.subtitle)}</p>` : ''}
              </div>
              ${
                item.reviewCount
                  ? `<span class="reviews">${item.reviewCount.toLocaleString('ru-RU')} отзывов</span>`
                  : ''
              }
            </div>

            ${item.address ? `<p class="meta-line"><strong>Адрес:</strong> ${escapeHtml(item.address)}</p>` : ''}
            ${item.openingHours ? `<p class="meta-line"><strong>Часы работы:</strong> ${escapeHtml(item.openingHours)}</p>` : ''}
            ${item.phone ? `<p class="meta-line"><strong>Телефон 2GIS:</strong> <a href="tel:${escapeHtml(item.phone)}">${escapeHtml(item.phone)}</a></p>` : ''}
            ${item.website ? `<p class="meta-line"><strong>Сайт:</strong> <a href="${escapeHtml(item.website)}" target="_blank" rel="noreferrer">${escapeHtml(item.website)}</a></p>` : ''}
            ${item.websitePhone ? `<p class="meta-line"><strong>Телефон с сайта:</strong> <a href="tel:${escapeHtml(item.websitePhone)}">${escapeHtml(item.websitePhone)}</a></p>` : ''}
            ${item.description ? `<p class="description">${escapeHtml(item.description)}</p>` : ''}

            <div class="actions">
              <a href="${escapeHtml(item.detailUrl)}" target="_blank" rel="noreferrer">Карточка 2GIS</a>
              <a href="${escapeHtml(item.mapUrl)}" target="_blank" rel="noreferrer">2GIS карта</a>
              <a href="${escapeHtml(item.yandexMapUrl)}" target="_blank" rel="noreferrer">Яндекс Карты</a>
              ${item.website ? `<a href="${escapeHtml(item.website)}" target="_blank" rel="noreferrer">Перейти на сайт</a>` : ''}
            </div>
          </div>
        </article>
      `,
    )
    .join('')
}

async function handleSubmit(event) {
  event.preventDefault()
  const profileConfig = getProfileConfig()

  updatePreview()
  submitButton.disabled = true
  submitButton.textContent = 'Ищу...'
  renderStats(null)
  resultsNode.innerHTML = ''
  setMessage(profileConfig.loading)

  try {
    const response = await fetch(`/api/search?${buildQueryString()}`)
    const payload = await response.json()

    if (!response.ok) {
      throw new Error(payload.details || payload.error || 'Ошибка запроса')
    }

    renderStats(payload)

    if (!payload.items.length) {
      setMessage(profileConfig.empty, 'empty')
      return
    }

    setMessage(`Готово. Найдено ${payload.count} карточек.`, 'success')
    renderResults(payload.items)
  } catch (error) {
    setMessage(
      error instanceof Error ? error.message : 'Не удалось получить результаты',
      'error',
    )
  } finally {
    submitButton.disabled = false
    submitButton.textContent = profileConfig.button
  }
}

for (const field of Object.values(fields)) {
  field.addEventListener('input', updatePreview)
  field.addEventListener('change', updatePreview)
}

fields.profile.addEventListener('change', updateProfileUi)
form.addEventListener('submit', handleSubmit)
updateProfileUi()
