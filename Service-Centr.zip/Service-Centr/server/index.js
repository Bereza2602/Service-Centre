import http from 'node:http'
import { readFile } from 'node:fs/promises'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

import { searchElectronics } from '../parsers/electronics/server/search-service.js'
import { searchPlaces } from '../parsers/restaurants/server/two-gis.js'
import {
  CATEGORY_DEFINITIONS,
  fetchEntertainmentPlaces,
} from '../parsers/entertainment/server/entertainment.js'
import { searchPharmacies } from '../parsers/pharmacy/server/pharmacy-search.js'

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const publicDir = path.resolve(__dirname, '../public')
const PORT = Number(process.env.PORT || 8090)

const MIME_TYPES = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
}

const PARSERS = [
  {
    id: 'electronics',
    title: 'Электроника',
    shortTitle: 'Техника',
    description: 'Ищет товары по магазинам и агрегаторам: бренд, категория, цена, источник.',
    source: 'Локальная база и магазины электроники',
    endpoint: '/api/search/electronics',
  },
  {
    id: 'restaurants',
    title: 'Рестораны',
    shortTitle: '2GIS',
    description: 'Ищет рестораны, кафе и организации через живой поиск 2GIS.',
    source: '2GIS',
    endpoint: '/api/search/restaurants',
  },
  {
    id: 'entertainment',
    title: 'Досуг',
    shortTitle: 'Места',
    description: 'Собирает развлечения: кино, клубы, боулинг, квесты, бары и другие места.',
    source: 'OpenStreetMap, Nominatim и Overpass',
    endpoint: '/api/search/entertainment',
  },
  {
    id: 'pharmacy',
    title: 'Аптеки',
    shortTitle: 'Лекарства',
    description: 'Находит лекарства по городу, цене, наличию и аптечным источникам.',
    source: 'Аптечная демо-база и подготовленные источники',
    endpoint: '/api/search/pharmacy',
  },
]

function sendJson(response, statusCode, payload) {
  response.writeHead(statusCode, {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Content-Type': 'application/json; charset=utf-8',
  })

  response.end(JSON.stringify(payload))
}

async function sendFile(response, pathname) {
  const normalizedPath = pathname === '/' ? '/index.html' : pathname
  const resolvedPath = path.resolve(publicDir, `.${normalizedPath}`)

  if (!resolvedPath.startsWith(publicDir)) {
    response.writeHead(403)
    response.end('Forbidden')
    return
  }

  try {
    const file = await readFile(resolvedPath)
    response.writeHead(200, {
      'Content-Type': MIME_TYPES[path.extname(resolvedPath)] ?? 'application/octet-stream',
    })
    response.end(file)
  } catch {
    response.writeHead(404)
    response.end('Not found')
  }
}

function asNumber(value, fallback = null) {
  if (value === null || value === '') {
    return fallback
  }

  const parsed = Number(value)
  return Number.isFinite(parsed) ? parsed : fallback
}

async function runParser(parserId, searchParams) {
  if (parserId === 'electronics') {
    return searchElectronics({
      query: searchParams.get('query') || '',
      brand: searchParams.get('brand') || '',
      category: searchParams.get('category') || '',
      priceMin: asNumber(searchParams.get('priceMin')),
      priceMax: asNumber(searchParams.get('priceMax')),
      sortBy: searchParams.get('sortBy') || 'price-asc',
      sources: searchParams.get('sources') || '',
    })
  }

  if (parserId === 'pharmacy') {
    return searchPharmacies({
      city: searchParams.get('city') || 'ekaterinburg',
      query: searchParams.get('query') || '',
      maxPrice: asNumber(searchParams.get('maxPrice')),
      sortBy: searchParams.get('sortBy') || 'price-asc',
      onlyInStock: searchParams.get('onlyInStock') === 'true',
      sourceIds: searchParams.has('sources')
        ? searchParams
            .get('sources')
            .split(',')
            .map((source) => source.trim())
            .filter(Boolean)
        : null,
      limit: asNumber(searchParams.get('limit'), 100),
    })
  }

  if (parserId === 'entertainment') {
    return fetchEntertainmentPlaces({
      city: searchParams.get('city') || 'Екатеринбург',
      categories: (searchParams.get('categories') || '')
        .split(',')
        .map((category) => category.trim())
        .filter(Boolean),
      limit: asNumber(searchParams.get('limit'), undefined),
      searchText: searchParams.get('searchText') || '',
    })
  }

  if (parserId === 'restaurants') {
    const limit = asNumber(searchParams.get('limit'), 8)

    return searchPlaces({
      city: searchParams.get('city') || 'ekaterinburg',
      query: searchParams.get('query') || '',
      profile: searchParams.get('profile') || 'restaurants',
      limit,
      withWebsitePhones: searchParams.get('withWebsitePhones') !== '0',
      services: (searchParams.get('services') || '').split(',').map(s => s.trim()).filter(Boolean),
    })
  }

  throw new Error(`Unknown parser: ${parserId}`)
}

const server = http.createServer(async (request, response) => {
  if (!request.url) {
    sendJson(response, 400, { error: 'Empty request URL' })
    return
  }

  if (request.method === 'OPTIONS') {
    response.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    })
    response.end()
    return
  }

  const url = new URL(request.url, `http://${request.headers.host}`)

  if (request.method === 'GET' && url.pathname === '/api/health') {
    sendJson(response, 200, { ok: true, parsers: PARSERS.map((parser) => parser.id) })
    return
  }

  if (request.method === 'GET' && url.pathname === '/api/parsers') {
    sendJson(response, 200, {
      parsers: PARSERS,
      entertainmentCategories: CATEGORY_DEFINITIONS,
    })
    return
  }

  const searchMatch = url.pathname.match(/^\/api\/search\/([^/]+)$/)
  if (request.method === 'GET' && searchMatch) {
    const parserId = searchMatch[1]

    try {
      const payload = await runParser(parserId, url.searchParams)
      const parser = PARSERS.find((item) => item.id === parserId)

      sendJson(response, 200, {
        parser,
        payload,
      })
    } catch (error) {
      sendJson(response, 500, {
        error: 'Не удалось выполнить поиск',
        details: error instanceof Error ? error.message : 'Unknown error',
      })
    }

    return
  }

  if (request.method === 'GET') {
    await sendFile(response, url.pathname)
    return
  }

  response.writeHead(405)
  response.end('Method not allowed')
})

server.listen(PORT, () => {
  console.log(`Unified parser center is running on http://localhost:${PORT}`)
})
